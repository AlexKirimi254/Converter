package com.alexa.alexa.adapters;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.menu.SongOptions;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.view.TintedImageView;
import java.util.ArrayList;
import java.util.List;
import android.graphics.BitmapFactory;


public class SongListAdaptor extends BaseAdapter
{
    Handler handle = new Handler();
    LayoutInflater inf;
    List<SongItem> songList = new ArrayList<>();
    MainActivity ctx;
    SongItem currentSong;
    ThemeManager.Theme theme;

    public SongListAdaptor(MainActivity ctx){
        this.ctx = ctx;
        inf = LayoutInflater.from(ctx);
        theme = ThemeManager.getTheme();
    }

    public void update(List<SongItem> list){
        this.songList = list;
        notifyDataSetChanged();
    }

    public void setCurrent(SongItem songitem){
        //
        this.currentSong = songitem;
        notifyDataSetChanged();
    }

    public void setTheme(ThemeManager.Theme theme){
        this.theme = theme;
        //notifyDataSetChanged();
    }

    public int getPos(SongItem si){
        return songList.indexOf(si);
    }

    @Override
    public int getCount(){
        return songList.size();
    }

    @Override
    public SongItem getItem(int p1){
        return songList.get(p1);
    }

    @Override
    public long getItemId(int p1){
        return p1;
    }

    //@Override
    public CharSequence[] getAutofillOptions()
    {
        return null;
    }

    @Override
    public View getView(int pos, View p2, ViewGroup p3)
    {
        final SongItem item = songList.get(pos);

        View v = inf.inflate(R.layout.songlist_item, null, false);
        TextView title = (TextView) v.findViewById(R.id.songlist_itemTitle);
        title.setText(item.title);
       // title.setTextColor(theme.text);
        //
        TextView artist = (TextView) v.findViewById(R.id.songlist_itemArtist);
        artist.setText(item.artist);
     //   artist.setTextColor(theme.text);
        //
        final ImageView art = (ImageView) v.findViewById(R.id.songlist_item_albumart);
   //   art.setBackgroundDrawable(new BitmapDrawable(ctx.getResources(),item.getThumbnail()));
        
        

        v.findViewById(R.id.songlist_item_more).setOnClickListener(new View.OnClickListener(){
                public void onClick(View v){
                    new SongOptions(ctx, item).show();
                }
            });
       v.setBackgroundColor(theme.background);

        TintedImageView more_icon = (TintedImageView) v.findViewById(R.id.songlist_items_more_icon);
        
		if (currentSong != null && currentSong.equals(item)) {
            
     
            v.setBackgroundColor(R .color.colorPrimary);
            title.setTextColor(theme.text);
            artist.setTextColor(theme.text);

                  
            
        }

        v.setTag(item);
        return v;
    }

    class J{
        Bitmap bmp;
        int color;
    }
    J cj = new J();

}



/*
public class SongListAdaptor extends BaseAdapter {

    Handler handle = new Handler();
    LayoutInflater inf;
    List<SongItem> songList = new ArrayList<>();
    MainActivity ctx;
    SongItem currentSong;
    ThemeManager.Theme theme;

    public SongListAdaptor(MainActivity ctx) {
        this.ctx = ctx;
        inf = LayoutInflater.from(ctx);
        // theme = ThemeManager.get().getTheme(); // Assuming theme is set later
    }

    public void update(List<SongItem> list) {
        this.songList = list;
        notifyDataSetChanged();
    }

    public void setCurrent(SongItem songitem) {
        this.currentSong = songitem;
        notifyDataSetChanged();
    }

    public void setTheme(ThemeManager.Theme theme) {
        this.theme = theme;
    }

    public int getPos(SongItem si) {
        return songList.indexOf(si);
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public SongItem getItem(int pos) {
        return songList.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return pos;
    }

    @Override
    public View getView(int pos, View convertView, ViewGroup parent) {
        final SongItem item = songList.get(pos);

        // Inflate the view if convertView is null
        if (convertView == null) {
            convertView = inf.inflate(R.layout.songlist_item, parent, false);
        }

        TextView title = (TextView) convertView.findViewById(R.id.songlist_itemTitle);
        TextView artist = (TextView) convertView.findViewById(R.id.songlist_itemArtist);
        final ImageView art = (ImageView) convertView.findViewById(R.id.songlist_item_albumart);

        // Set song title and artist
        title.setText(item.getTitle());
        title.setTextColor(theme.text);
        artist.setText(item.getArtist());
        artist.setTextColor(theme.text);

        // Set album art
        if (item.getIconPath() != null) {
            // Set song-specific album art if available
            art.setBackgroundDrawable(new BitmapDrawable(ctx.getResources(), item.getIconPath()));
        } else {
            // Load default image asynchronously if no specific icon
            loadThumbnailAsync(art, R.drawable.cover_f, theme.icon);
        }

        // More options button
        convertView.findViewById(R.id.songlist_item_more).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new SongOptions(ctx, item).show();
                }
            });

        // Setting up more icon tint
        TintedImageView moreIcon = (TintedImageView) convertView.findViewById(R.id.songlist_items_more_icon);
        moreIcon.setTint(theme.icon);

        // Highlight the current song
        if (currentSong != null && currentSong.equals(item)) {
            highlightCurrentSong(convertView, title, artist, art);
        }

        convertView.setTag(item);
        return convertView;
    }

    private void highlightCurrentSong(View view, TextView title, TextView artist, final ImageView art) {
        view.setBackgroundColor(theme.text);
        title.setTextColor(theme.background);
        artist.setTextColor(theme.background);

        // More icon for current song gets inverted colors
        TintedImageView moreIcon = (TintedImageView) view.findViewById(R.id.songlist_items_more_icon);
        moreIcon.setTint(theme.background);

        // Update album art for the current song if necessary
        if (cj.color != theme.background) {
            App.runInBackground(new Runnable() {
                    @Override
                    public void run() {
                        // Use the newly created tintBitmap method
                        final Bitmap tintedBitmap = BitmapUtils.tintBitmap(BitmapFactory.decodeResource(ctx.getResources(), R.drawable.cover_f), theme.background);
                        if (tintedBitmap != null) {
                            App.runInUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        art.setImageBitmap(tintedBitmap);
                                        cj.bmp = tintedBitmap;
                                        cj.color = theme.background;
                                    }
                                });
                        }
                    }
                });
        } else {
            art.setImageBitmap(cj.bmp);
        }
    }

    // Load album art thumbnail asynchronously
    private void loadThumbnailAsync(final ImageView imageView, final int resourceId, final int tintColor) {
        // Set placeholder image while loading
        imageView.setImageResource(R.drawable.cover_f);

        App.runInBackground(new Runnable() {
                @Override
                public void run() {
                    // Tint the image asynchronously using the new method
                    final Bitmap tintedBitmap = BitmapUtils.tintBitmap(BitmapFactory.decodeResource(ctx.getResources(), resourceId), tintColor);
                    if (tintedBitmap != null) {
                        App.runInUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    imageView.setImageBitmap(tintedBitmap);
                                }
                            });
                    }
                }
            });
    }

    // Cache class to manage album art for current song
    class J {
        Bitmap bmp;
        int color;
    }

    J cj = new J();
}

*/
