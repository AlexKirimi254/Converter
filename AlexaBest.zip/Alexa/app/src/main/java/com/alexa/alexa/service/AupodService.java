package com.alexa.alexa.service;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import java.util.List;

public class AupodService {
    private List<SongItem> songQueue;
    private int currentSongIndex;
    private AudioService audioService;

    public AupodService(AudioService audioService) {
        this.audioService = audioService;
        this.songQueue = new ArrayList<>();
        this.currentSongIndex = -1; // No song is currently playing
    }

    // Add a song to the queue
    public void enqueueSong(SongItem song) {
        songQueue.add(song);
    }

    // Play the next song in the queue
    public void playNext() {
        if (!songQueue.isEmpty()) {
            currentSongIndex = (currentSongIndex + 1) % songQueue.size();
            playCurrentSong();
        }
    }

    // Play the current song
    private void playCurrentSong() {
        if (currentSongIndex >= 0 && currentSongIndex < songQueue.size()) {
            SongItem song = songQueue.get(currentSongIndex);
            audioService.playSong(song);
        }
    }

    // Play a specific song from the queue
    public void playSongAt(int index) {
        if (index >= 0 && index < songQueue.size()) {
            currentSongIndex = index;
            playCurrentSong();
        }
    }

    // Pause playback
    public void pause() {
        audioService.pause();
    }

    // Resume playback
    public void resume() {
        audioService.resume();
    }

    // Clear the queue
    public void clearQueue() {
        songQueue.clear();
        currentSongIndex = -1; // Reset current song index
    }

    // Get the current song
    public SongItem getCurrentSong() {
        if (currentSongIndex >= 0) {
            return songQueue.get(currentSongIndex);
        }
        return null; // No song is currently playing
    }

    // Get the song queue
    public List<SongItem> getSongQueue() {
        return songQueue;
    }
}

