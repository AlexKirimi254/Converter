package com.alexa.alexa.library;


import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Singleton class that manages songs, artists, playback queues, and playlists.
 */
public class SongLibrary {
    private static final String TAG = "SongLibrary";

    // Singleton instance
    private static volatile SongLibrary instance;

    // Thread-safe lists for songs and artists
    private final List<SongItem> songList;
    private final List<ArtistItem> artistList;

    // Executor for background tasks
    private final ExecutorService executor;

    // Handler for posting results to the main thread
    private final Handler mainHandler;

    // Playback queue
    private final List<SongItem> playbackQueue;

    // Playlists mapped by playlist ID
    private final HashMap<String, Playlist> playlists;

    private boolean isDiscovering;

    /**
     * Private constructor to enforce singleton pattern.
     */
    private SongLibrary() {
        playlists = new HashMap<>(); // Removed sample playlist initialization
        songList = Collections.synchronizedList(new ArrayList<SongItem>());
        artistList = Collections.synchronizedList(new ArrayList<ArtistItem>());
        executor = Executors.newFixedThreadPool(2);
        mainHandler = new Handler(Looper.getMainLooper());
        playbackQueue = Collections.synchronizedList(new ArrayList<SongItem>());
        isDiscovering = false;
    }

    /**
     * Gets the singleton instance of SongLibrary.
     *
     * @return The singleton SongLibrary instance.
     */
    public static SongLibrary getInstance() {
        if (instance == null) {
            synchronized (SongLibrary.class) {
                if (instance == null) {
                    instance = new SongLibrary();
                }
            }
        }
        return instance;
    }

    /**
     * Starts the song discovery process.
     *
     * @param context The application context.
     */
    public void start(final Context context) {
        if (!isDiscovering) {
            isDiscovering = true;
            update(context, new ResultCallback<List<SongItem>>() {
                    @Override
                    public void onResult(List<SongItem> result) {
                        isDiscovering = false;
                        Log.d(TAG, "Song discovery completed. Total songs found: " + result.size());
                        // Additional logic after discovery if needed
                    }
                });
        }
    }
    public Playlist getPlaylistByName(String playlistName) {
        if (playlistName == null || playlistName.trim().isEmpty()) {
            Log.e(TAG, "getPlaylistByName: Invalid playlist name.");
            return null;
        }

        // Assuming playlists are stored in a map or database.
        Playlist playlist = playlists.get(playlistName); // Or retrieve from database

        if (playlist != null) {
            Log.i(TAG, "getPlaylistByName: Playlist '" + playlistName + "' found.");
            return playlist;
        } else {
            Log.e(TAG, "getPlaylistByName: Playlist not found.");
            return null;
        }
    }
    
    public List<SongItem> loadPlaylist(String playlistName) {
        if (playlistName == null || playlistName.trim().isEmpty()) {
            Log.e(TAG, "loadPlaylist: Invalid playlist name.");
            return null;
        }

        // Assuming playlists are stored in a map or database where the key is the playlist name.
        Playlist playlist = getPlaylistByName(playlistName); // Retrieves the Playlist object

        if (playlist != null) {
            Log.i(TAG, "loadPlaylist: Playlist '" + playlistName + "' loaded successfully.");
            return playlist.getSongs(); // Assuming Playlist has a method to return the list of SongItems.
        } else {
            Log.e(TAG, "loadPlaylist: Playlist not found.");
            return null;
        }
    }
    
    public boolean updateSongTags(SongItem si, String title, String artist, String album) {
        if (si == null || title == null || artist == null || album == null) {
            Log.e(TAG, "updateSongTags: Invalid parameters.");
            return false;
        }

        // Update the SongItem properties
        si.setTitle(title);
        si.setArtist(artist);
        si.setAlbum(album);

        // Assuming a method to update this in persistent storage or database.
    //    boolean isUpdated = update(si); // This method would need to handle the persistence.

        if (true) {
            Log.i(TAG, "updateSongTags: Song tags updated successfully.");
            return true;
        } else {
            Log.e(TAG, "updateSongTags: Failed to update song tags.");
            return false;
        }
    }
    
        public Playlist createPlaylist(String playlistName) {
            if (playlistName == null || playlistName.trim().isEmpty()) {
                Log.e(TAG, "createPlaylist: Invalid playlist name.");
                return null;
            }
            synchronized (playlists) {
                // Check if a playlist with the same name already exists
                for (Playlist pl : playlists.values()) {
                    if (pl.getName().equalsIgnoreCase(playlistName)) {
                        Log.e(TAG, "createPlaylist: Playlist with name '" + playlistName + "' already exists.");
                        return null; // Playlist with the same name already exists
                    }
                }
                Playlist newPlaylist = new Playlist(playlistName);
                playlists.put(newPlaylist.getId(), newPlaylist);
                Log.d(TAG, "createPlaylist: Created playlist '" + playlistName + "' with ID " + newPlaylist.getId());
                return newPlaylist;
            }
        }

        // Other methods...
    
    /**
     * Updates the song list from the device's media store.
     *
     * @param context  The application context.
     * @param callback The callback to handle the result.
     */
    public void update(final Context context, final ResultCallback<List<SongItem>> callback) {
        executor.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        // Replace SongRetreiverCursor.get with your actual method to fetch songs
                        List<SongItem> fetchedSongs = SongRetreiverCursor.get(context);
                        synchronized (songList) {
                            songList.clear();
                            songList.addAll(fetchedSongs);
                        }
                        generateArtistList();

                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (callback != null) {
                                        callback.onResult(Collections.unmodifiableList(new ArrayList<SongItem>(songList)));
                                    }
                                }
                            });
                    } catch (final Exception e) {
                        Log.e(TAG, "Error fetching songs: ", e);
                        mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (callback != null) {
                                        // You can enhance the callback to handle errors separately
                                        callback.onResult(Collections.<SongItem>emptyList());
                                    }
                                }
                            });
                    }
                }
            });
    }

    /**
     * Retrieves all songs asynchronously.
     *
     * @param context  The application context.
     * @param callback The callback to handle the result.
     */
    public void getAllSongs(Context context, ResultCallback<List<SongItem>> callback) {
        update(context, callback);
    }

    /**
     * Retrieves songs by a specific artist.
     *
     * @param artist The ArtistItem object.
     * @return An unmodifiable list of SongItem objects by the artist.
     */
    public List<SongItem> getSongsByArtist(ArtistItem artist) {
        if (artist == null) {
            return Collections.emptyList();
        }

        List<SongItem> result = new ArrayList<SongItem>();
        synchronized (songList) {
            for (SongItem song : songList) {
                if (artist.getName().equalsIgnoreCase(song.getArtist())) {
                    result.add(song);
                }
            }
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * Retrieves an artist by their ID.
     *
     * @param artistId The artist's ID.
     * @return The ArtistItem object, or null if not found.
     */
    public ArtistItem getArtistById(int artistId) {
        synchronized (artistList) {
            for (ArtistItem artist : artistList) {
                if (artist.getId() == artistId) {
                    return artist;
                }
            }
        }
        return null;
    }

    /**
     * Retrieves songs by the artist's ID asynchronously.
     *
     * @param artistId The artist's ID.
     * @param callback The callback to handle the result.
     */
    public void getSongsByArtist(final int artistId, final ResultCallback<List<SongItem>> callback) {
        executor.submit(new Runnable() {
                @Override
                public void run() {
                    ArtistItem artist = getArtistById(artistId);
                    final List<SongItem> filteredSongs = getSongsByArtist(artist);

                    mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null) {
                                    callback.onResult(filteredSongs);
                                }
                            }
                        });
                }
            });
    }

    /**
     * Retrieves all artists asynchronously.
     *
     * @param callback The callback to handle the result.
     */
    public void getAllArtists(final ResultCallback<List<ArtistItem>> callback) {
        executor.submit(new Runnable() {
                @Override
                public void run() {
                    generateArtistList();
                    mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (callback != null) {
                                    callback.onResult(Collections.unmodifiableList(new ArrayList<ArtistItem>(artistList)));
                                }
                            }
                        });
                }
            });
    }

    /**
     * Generates the list of artists from the song list.
     */
    private void generateArtistList() {
        HashMap<String, ArtistItem> artistMap = new HashMap<String, ArtistItem>();
        synchronized (songList) {
            for (SongItem song : songList) {
                String artistName = song.getArtist();
                if (artistName == null || artistName.trim().isEmpty()) {
                    continue;
                }

                String key = artistName.toLowerCase();
                ArtistItem artist = artistMap.get(key);
                if (artist == null) {
                    artist = new ArtistItem();
                    artist.setName(artistName);
                    artist.setId(generateArtistId(artistName));
                    artistMap.put(key, artist);
                }
                artist.setSongcount(artist.getSongcount() + 1);
            }
        }

        synchronized (artistList) {
            artistList.clear();
            artistList.addAll(artistMap.values());

            // Sort artists alphabetically
            Collections.sort(artistList, new Comparator<ArtistItem>() {
                    @Override
                    public int compare(ArtistItem l, ArtistItem r) {
                        return l.getName().compareToIgnoreCase(r.getName());
                    }
                });
        }
    }

    /**
     * Generates a unique ID for an artist based on their name.
     * This is a placeholder; in a real scenario, IDs should be consistent and preferably from a reliable source.
     *
     * @param artistName The artist's name.
     * @return A unique integer ID.
     */
    private int generateArtistId(String artistName) {
        return artistName.toLowerCase().hashCode();
    }

    /**
     * Shuts down the executor service gracefully.
     * Call this method when the SongLibrary is no longer needed to free resources.
     */
    public void shutdown() {
        executor.shutdown();
    }

    /**
     * Adds a song to the playback queue.
     *
     * @param song The SongItem to add to the queue.
     */
    public void addToQueue(SongItem song) {
        if (song == null) return;
        synchronized (playbackQueue) {
            playbackQueue.add(song);
        }
    }

    /**
     * Removes a song from the playback queue.
     *
     * @param song The SongItem to remove from the queue.
     */
    public void removeFromQueue(SongItem song) {
        if (song == null) return;
        synchronized (playbackQueue) {
            playbackQueue.remove(song);
        }
    }

    /**
     * Retrieves the current playback queue.
     *
     * @return An unmodifiable list representing the playback queue.
     */
    public List<SongItem> getPlaybackQueue() {
        synchronized (playbackQueue) {
            return Collections.unmodifiableList(new ArrayList<SongItem>(playbackQueue));
        }
    }

    /**
     * Clears the playback queue.
     */
    public void clearQueue() {
        synchronized (playbackQueue) {
            playbackQueue.clear();
        }
    }

    /**
     * Creates a new playlist with the given name.
     *
     * @param playlistName The name of the playlist.
     * @return The newly created Playlist object, or null if creation failed.
     */
    /*public Playlist createPlaylist(String playlistName) {
        if (playlistName == null || playlistName.trim().isEmpty()) {
            Log.e(TAG, "createPlaylist: Invalid playlist name.");
            return null;
        }
        synchronized (playlists) {
            // Check if a playlist with the same name already exists
            for (Playlist pl : playlists.values()) {
                if (pl.getName().equalsIgnoreCase(playlistName)) {
                    Log.e(TAG, "createPlaylist: Playlist with name '" + playlistName + "' already exists.");
                    return null; // Playlist with the same name already exists
                }
            }
            Playlist newPlaylist = new Playlist(playlistName);
            playlists.put(newPlaylist.getId(), newPlaylist);
            Log.d(TAG, "createPlaylist: Created playlist '" + playlistName + "' with ID " + newPlaylist.getId());
            return newPlaylist;
        }
    }
*/
    /**
     * Deletes an existing playlist.
     *
     * @param playlist The Playlist object to delete.
     * @return True if the playlist was deleted successfully, false if the playlist does not exist.
     */
    public boolean deletePlaylist(Playlist playlist) {
        if (playlist == null || playlist.getId() == null || playlist.getId().isEmpty()) {
            Log.e(TAG, "deletePlaylist: Invalid playlist.");
            return false;
        }
        synchronized (playlists) {
            if (playlists.containsKey(playlist.getId())) {
                playlists.remove(playlist.getId());
                Log.d(TAG, "deletePlaylist: Deleted playlist '" + playlist.getName() + "'.");
                return true;
            }
            Log.e(TAG, "deletePlaylist: Playlist with ID " + playlist.getId() + " does not exist.");
            return false;
        }
    }

    /**
     * Adds a song to a specific playlist.
     *
     * @param playlist The Playlist object.
     * @param song     The SongItem to add.
     * @return True if the song was added successfully, false otherwise.
     */
    public boolean addToPlaylist(Playlist playlist, SongItem song) {
        if (playlist == null || song == null) {
            Log.e(TAG, "addToPlaylist: Playlist or SongItem is null.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                existingPlaylist.addSong(song);
                existingPlaylist.updateDateModified();
                Log.d(TAG, "addToPlaylist: Added song '" + song.getTitle() + "' to playlist '" + existingPlaylist.getName() + "'.");
                return true;
            }
            Log.e(TAG, "addToPlaylist: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Removes a song from a specific playlist.
     *
     * @param playlist The Playlist object.
     * @param song     The SongItem to remove.
     * @return True if the song was removed successfully, false otherwise.
     */
    public boolean removeFromPlaylist(Playlist playlist, SongItem song) {
        if (playlist == null || song == null) {
            Log.e(TAG, "removeFromPlaylist: Playlist or SongItem is null.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                boolean removed = existingPlaylist.removeSong(song);
                if (removed) {
                    existingPlaylist.updateDateModified();
                    Log.d(TAG, "removeFromPlaylist: Removed song '" + song.getTitle() + "' from playlist '" + existingPlaylist.getName() + "'.");
                } else {
                    Log.e(TAG, "removeFromPlaylist: Song '" + song.getTitle() + "' not found in playlist '" + existingPlaylist.getName() + "'.");
                }
                return removed;
            }
            Log.e(TAG, "removeFromPlaylist: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Retrieves all playlists.
     *
     * @return An unmodifiable list of Playlist objects.
     */
    public List<Playlist> getAllPlaylists() {
        synchronized (playlists) {
            return Collections.unmodifiableList(new ArrayList<Playlist>(playlists.values()));
        }
    }

    /**
     * Retrieves all songs in a specific playlist.
     *
     * @param playlist The Playlist object.
     * @return An unmodifiable list of SongItem objects in the playlist, or an empty list if the playlist does not exist.
     */
    public List<SongItem> getPlaylistSongs(Playlist playlist) {
        if (playlist == null || playlist.getId() == null || playlist.getId().isEmpty()) {
            Log.e(TAG, "getPlaylistSongs: Invalid playlist.");
            return Collections.emptyList();
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                return existingPlaylist.getSongs();
            }
            Log.e(TAG, "getPlaylistSongs: Playlist with ID " + playlist.getId() + " not found.");
            return Collections.emptyList();
        }
    }

    /**
     * Renames an existing playlist.
     *
     * @param playlist The Playlist object to rename.
     * @param newName  The new name for the playlist.
     * @return True if the playlist was renamed successfully, false otherwise.
     */
    public boolean renamePlaylist(Playlist playlist, String newName) {
        if (playlist == null || newName == null || newName.trim().isEmpty()) {
            Log.e(TAG, "renamePlaylist: Invalid parameters.");
            return false;
        }
        synchronized (playlists) {
            // Check if another playlist with the new name already exists
            for (Playlist pl : playlists.values()) {
                if (pl.getName().equalsIgnoreCase(newName)) {
                    Log.e(TAG, "renamePlaylist: Another playlist with name '" + newName + "' already exists.");
                    return false; // Another playlist with the new name exists
                }
            }
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                existingPlaylist.setName(newName);
                existingPlaylist.updateDateModified();
                Log.d(TAG, "renamePlaylist: Renamed playlist to '" + newName + "'.");
                return true;
            }
            Log.e(TAG, "renamePlaylist: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Moves a song within a specific playlist.
     *
     * @param playlist    The Playlist object.
     * @param song        The SongItem to move.
     * @param newPosition The new position to move the song to.
     * @return True if the song was moved successfully, false otherwise.
     */
    public boolean moveSongInPlaylist(Playlist playlist, SongItem song, int newPosition) {
        if (playlist == null || song == null || newPosition < 0) {
            Log.e(TAG, "moveSongInPlaylist: Invalid parameters.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                boolean moved = existingPlaylist.moveSong(song, newPosition);
                if (moved) {
                    existingPlaylist.updateDateModified();
                    Log.d(TAG, "moveSongInPlaylist: Moved song '" + song.getTitle() + "' to position " + newPosition + " in playlist '" + existingPlaylist.getName() + "'.");
                } else {
                    Log.e(TAG, "moveSongInPlaylist: Failed to move song '" + song.getTitle() + "' in playlist '" + existingPlaylist.getName() + "'.");
                }
                return moved;
            }
            Log.e(TAG, "moveSongInPlaylist: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Sorts the songs in a specific playlist alphabetically by title.
     *
     * @param playlist The Playlist object to sort.
     * @return True if the playlist was sorted successfully, false otherwise.
     */
    public boolean sortPlaylistByTitle(Playlist playlist) {
        if (playlist == null) {
            Log.e(TAG, "sortPlaylistByTitle: Playlist is null.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                existingPlaylist.sortByTitle();
                Log.d(TAG, "sortPlaylistByTitle: Sorted playlist '" + existingPlaylist.getName() + "' by title.");
                return true;
            }
            Log.e(TAG, "sortPlaylistByTitle: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Sorts the songs in a specific playlist by their duration (shortest to longest).
     *
     * @param playlist The Playlist object to sort.
     * @return True if the playlist was sorted successfully, false otherwise.
     */
    public boolean sortPlaylistByDuration(Playlist playlist) {
        if (playlist == null) {
            Log.e(TAG, "sortPlaylistByDuration: Playlist is null.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                existingPlaylist.sortByDuration();
                Log.d(TAG, "sortPlaylistByDuration: Sorted playlist '" + existingPlaylist.getName() + "' by duration.");
                return true;
            }
            Log.e(TAG, "sortPlaylistByDuration: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Shuffles the songs in a specific playlist randomly.
     *
     * @param playlist The Playlist object to shuffle.
     * @return True if the playlist was shuffled successfully, false otherwise.
     */
    public boolean shufflePlaylist(Playlist playlist) {
        if (playlist == null) {
            Log.e(TAG, "shufflePlaylist: Playlist is null.");
            return false;
        }
        synchronized (playlists) {
            Playlist existingPlaylist = playlists.get(playlist.getId());
            if (existingPlaylist != null) {
                existingPlaylist.shuffle();
                Log.d(TAG, "shufflePlaylist: Shuffled playlist '" + existingPlaylist.getName() + "'.");
                return true;
            }
            Log.e(TAG, "shufflePlaylist: Playlist with ID " + playlist.getId() + " not found.");
            return false;
        }
    }

    /**
     * Callback interface for asynchronous operations.
     *
     * @param <T> The type of the result.
     */
    public interface ResultCallback<T> {
        void onResult(T result);
    }
}

