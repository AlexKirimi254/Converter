package com.alexa.alexa.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.ActivityAdapters.PlaylistsActivitySongsAdapter;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.menu.CurrentSongOptions;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.FastBlur;
import com.alexa.alexa.view.TintedImageView;
import java.util.ArrayList;
import java.util.List;

public class PlaylistDetailsActivity extends BaseActivity implements
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
View.OnClickListener
{

	@Override
	public void onSearchResultItemClick(SongItem si)
	{

	}

	@Override
	public void onSongsListUpdated(List<SongItem> ulist)
	{

	}


    private AudioService audioService;


       private TextView songTitle, songArtist;

    private ArrayList<SongItem> songQueue = new ArrayList<>();


    private Handler handle;
    //private SongItem mCurrentSong;
    private List<Playlist> playlists;
    private ArrayList<SongItem> songList = new ArrayList<>();
    private String playlistName;

    // UI Components
    private ListView songListView;
    private TextView playlistNameView;
    private PlaylistsActivitySongsAdapter songAdapter;

    private TextView currentTitle, currentArtist;
    private TextView trackTimeCurrent, trackTimeDuration;
    private LinearLayout art2Background;
    private ImageView currentArt;

    private TintedImageView playpauseIcon;
    private SeekBar seeker;
    private Runnable seekerTick;
    private boolean seektouch;
    

	private List<SongItem> playlistSongs;


	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_playlist);
		init();
	}

    private void init() {
        handle = new Handler();
        currentTitle = findView(R.id.auplayer_tv_title);
        currentArtist = findView(R.id.auplayer_tv_artist);
        art2Background = findView(R.id.aupalyer_iv_art2_background);
        currentArt = findView(R.id.auplayer_iv_art);
        playpauseIcon = findView(R.id.auplayer_btn_playpause);

        // Initialize views
        songListView = findViewById(R.id.list_view_list1);
        playlistNameView = findViewById(R.id.playlist_name_view);

        // Get the Intent and data

        playlistSongs = getIntent().getParcelableArrayListExtra("PLAYLIST_SONGS");

        ListView listView = findViewById(R.id.list_view_list1);
        PlaylistsActivitySongsAdapter songAdapter = new PlaylistsActivitySongsAdapter(this, playlistSongs);
        listView.setAdapter(songAdapter);

        // Handle song click to start playback from that song
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    audioService.playSongsFromPlaylist(playlistSongs, position);
                }
            });



        // Initialize SeekBar and its listeners
        seeker = findView(R.id.aupalyer_seeker);
        seeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar p1, int pos, boolean touch) {
                    if (audioService != null && seektouch) {
                        audioService.seekTo(pos);
                        trackTimeCurrent.setText(formatTime(pos));
                    }
                }

                private CharSequence formatTime(int pos) {
                    int minutes = pos / 1000 / 60;
                    int seconds = (pos / 1000) % 60;
                    return String.format("%02d:%02d", minutes, seconds);
                }

                @Override
                public void onStartTrackingTouch(SeekBar p1) {
                    stopSeeker();
                    seektouch = true;
                }

                private void stopSeeker() {
                    handle.removeCallbacks(seekerTick);
                }

                @Override
                public void onStopTrackingTouch(SeekBar p1) {
                    seektouch = false;
                    if (audioService != null && audioService.isPlaying()) {
                        startSeeker();
                    }
                }

                private void startSeeker() {
                    handle.post(seekerTick);
                }
            });

        seekerTick = new Runnable() {
            @Override
            public void run() {
                if (audioService != null) {
                    int pos = audioService.getCurrentPosition();
                    seeker.setProgress(pos);
                    trackTimeCurrent.setText(formatTime(pos));
                    handle.postDelayed(this, 1000);
                }
            }

            private CharSequence formatTime(int pos) {
                int minutes = pos / 1000 / 60;
                int seconds = (pos / 1000) % 60;
                return String.format("%02d:%02d", minutes, seconds);
            }
        };

        trackTimeCurrent = findView(R.id.auplayer_currentpos);
        trackTimeDuration = findView(R.id.auplayer_duration);

        // Set clickable buttons
        setClickable(R.id.auplayer_btn_playpause);
        setClickable(R.id.auplayer_btn_prev);
        setClickable(R.id.auplayer_btn_next);
        setClickable(R.id.auplayer_btn_options);
        setClickable(R.id.auplayer_btn_back);

        // Initialize click listeners for playback controls
       // initializePlaybackControls();
    }



    /**
     * Example of playing a song from the AudioService via App class.
     */
    private void playSong(SongItem song) {
        AudioService audioService = App.get().getAudioService();
        if (audioService != null) {
            audioService.playSong(song); // Call the play song method
        } else {
            Toast.makeText(this, "Audio Service not connected", Toast.LENGTH_SHORT).show();
        }
    }



    private void updateInfo(){
        final SongItem si = audioService.getCurrentSong();
        if(audioService==null || si==null){
            return;
        }

        currentTitle.setText(si.title);
        currentArtist.setText(si.artist);

        hideView(R.id.auplayer_iv_art_b);
        if(si.getId()!=null){
            currentArt.setImageBitmap(si.getThumbnail());
            setLargeArt(si.getThumbnail());
        }else{
            App.runInBackground(new Runnable(){
                    public void run(){
                        final Bitmap bmp = BitmapUtils.tint(ctx.getResources(), R.drawable.cover_f, ThemeManager.getTheme().icon);
                        if(bmp!=null){
                            handle.post(new Runnable(){
                                    public void run(){
                                        currentArt.setImageBitmap(bmp);
                                    }
                                });
                        }
                    }
                });
            //showView(R.id.auplayer_iv_art_b);
            setLargeArt( BitmapFactory.decodeResource(ctx.getResources(), R.drawable.fill));
        }

        if(audioService!=null){
            if(audioService.isPlaying()){
                playpauseIcon.setBackgroundResource(R.drawable.ic_pause);
            }else{
                playpauseIcon.setBackgroundResource(R.drawable.ic_play);
            }
        }

        playpauseIcon.reset();

        //playpauseIcon.setTint(tm.);

        int pos = audioService.getCurrentPosition();
        trackTimeDuration.setText(formatTime((int)si.duration));
        trackTimeCurrent.setText(formatTime(pos));

        seeker.setMax((int)si.duration);
        seeker.setProgress(pos);

        //
    }

    private void setLargeArt(final Bitmap bmp){
        art2Background.setBackgroundDrawable(new BitmapDrawable(bmp));
        App.runInBackground(new Runnable(){
                public void run(){
                    final Bitmap img = FastBlur.fastblur(bmp,0.2f,3);
                    if(img!=null){
                        App.runInUiThread(new Runnable(){
                                public void run(){
                                    art2Background.setBackgroundDrawable(new BitmapDrawable(img));
                                }
                            });
                    }
                }
            });
    }


	ThemeManager.Theme theme;

	// todo: this takes too long
	@Override
	protected void onApplyTheme(ThemeManager.Theme theme)
	{
		super.onApplyTheme(theme);
		this.theme = theme;
		//
		themer.dispatchMessage(new Message());
	}

	Handler themer = new Handler(){
		@Override
		public void handleMessage(Message msg)
		{
			super.handleMessage(msg);
			//
			setTextViewsColor(theme.text,
							  trackTimeCurrent,
							  trackTimeDuration,
							  currentArtist,
							  currentTitle);
			//
			currentTitle.setBackgroundColor(theme.background);
			currentArtist.setBackgroundColor(theme.background);
			//
			setTintablesTint(theme.icon,
							 R.id.au1,
							 R.id.au2,
							 R.id.au3,
							 R.id.au4,
							 R.id.auplayer_btn_playpause);
			//
			seeker.getProgressDrawable().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
			seeker.getThumb().setColorFilter(theme.icon, PorterDuff.Mode.SRC_ATOP);
		}
	};


    private void startSeeker(){
        stopSeeker();
        handle.postDelayed(seekerTick,0);
    }

    private void stopSeeker(){
        handle.removeCallbacks(seekerTick);
        handle.removeCallbacks(seekerTick);
    }

    private String formatTime(int time){
        //String t = "";
        int hrs = (int) (time/ (1000*60*60)) % 60;
        int min = (int) ( time/ (1000*60)) % 60;
        int sec = (int) (time /1000) % 60;
        if(hrs==0){
            return d(min)+":"+d(sec);
        }

        return d(hrs)+":"+d(min)+":"+d(sec);
    }

    private String d(int t){
        if(t<10){
            return "0"+t;
        }
        return ""+t;
    }

    @Override
    public void onClick(View v){
        int id = v.getId();
        switch(id){
            case R.id.auplayer_btn_playpause:
                if(audioService != null){
                    audioService.playPause();
                }
                break;
            case R.id.auplayer_btn_next:
                if(audioService != null){
                    audioService.playNext();
                }
                break;
            case R.id.auplayer_btn_prev:
                if(audioService != null){
                    audioService.playPrev();
                }
                break;
            case R.id.auplayer_btn_back:
                finish();
                break;
            case R.id.auplayer_btn_menu_songs:
                // Get the current song queue from the audio service
                startActivity(PlayingQueueActivity.class);
                break;
            case R.id.auplayer_btn_options:
                new CurrentSongOptions(this, audioService.getCurrentSong()).show();
                break;
        }
    }




    @Override
    public void onAudioServiceConnect(AudioService service){
        audioService = service;
        updateInfo();
        audioService.requestPlaystateUpdate();
    }

    @Override
    public void onPlaybackStart(){
        playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_pause);
        startSeeker();
    }

    @Override
    public void onPlaybackPause(){
        playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_play);
        stopSeeker();
    }

    @Override
    public void onPlaybackStop(){
        updateInfo();
        playpauseIcon.setBackgroundResourceAndReset(R.drawable.ic_play);
        stopSeeker();
    }

    @Override
    public void onSongChanged(SongItem newsong){
        updateInfo();
    }


    @Override
    protected void onPause(){
        stopSeeker();
        APEvents.getInstance().removePlaybackEventListener(this);
        super.onPause();
    }


    @Override
    protected void onResume(){
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        AudioService.connect(this, this);
        //
    }

    public void launchCurrentQueueActivity() {
        Intent intent = new Intent(this, PlaylistDetailsActivity.class);
        intent.putParcelableArrayListExtra("songQueue", songQueue);
        startActivity(intent);
    } 



	private void updateUI(SongItem song) {
		songTitle.setText(song.title);
		songArtist.setText(song.artist);
	}


}
