package com.alexa.alexa.models;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.alexa.alexa.utils.BitmapUtils;
import java.util.List;

/**
 * Represents an Album with relevant details.
 */
public class AlbumItem implements Parcelable {
    private int id;
    private String name;
    private String albumPath; // Path to the album file
    private int songcount;
    private int albumCount;
    private List<SongItem> songList;

    // Constructor with all details
    public AlbumItem(int id, String name, String albumPath, int songcount, int albumCount, List<SongItem> songList) {
        this.id = id;
        this.name = name;
        this.albumPath = albumPath;
        this.songcount = songcount;
        this.albumCount = albumCount;
        this.songList = songList;
    }

    // Default Constructor
    public AlbumItem(String albumName, List<SongItem> songList) {
        this.name = albumName;
        this.songList = songList;
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public String getAlbumName() {
        return name;
    }

    public String getAlbumPath() {
        return albumPath;
    }

    public int getSongcount() {
        return songcount;
    }

    public int getAlbumCount() {
        return albumCount;
    }

    public List<SongItem> getSongList() {
        return songList;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAlbumPath(String albumPath) {
        this.albumPath = albumPath;
    }

    public void setSongcount(int songcount) {
        this.songcount = songcount;
    }

    public void setAlbumCount(int albumCount) {
        this.albumCount = albumCount;
    }

    public void setSongList(List<SongItem> songList) {
        this.songList = songList;
    }

    // Parcelable implementation

    protected AlbumItem(Parcel in) {
        id = in.readInt();
        name = in.readString();
        albumPath = in.readString();
        songcount = in.readInt();
        albumCount = in.readInt();
        songList = in.createTypedArrayList(SongItem.CREATOR); // Read song list
    }

    public static final Creator<AlbumItem> CREATOR = new Creator<AlbumItem>() {
        @Override
        public AlbumItem createFromParcel(Parcel in) {
            return new AlbumItem(in);
        }

        @Override
        public AlbumItem[] newArray(int size) {
            return new AlbumItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(id);
        parcel.writeString(name);
        parcel.writeString(albumPath); // Write album path
        parcel.writeInt(songcount);
        parcel.writeInt(albumCount);
        parcel.writeTypedList(songList); // Write song list
    }
    public Bitmap getThumbnail() {
        try {
            // Implement logic to fetch the thumbnail based on the artist's ID or name
            // Here, I'm assuming you have a utility method that can fetch the thumbnail from a source
            // Example: return BitmapUtils.getArtistThumbnailFromId(this.id);
            return BitmapUtils.getSongThumbnailFromFile(name); // Replace with actual method
        } catch (Exception e) {
            Log.e("ArtistItem", "Error retrieving thumbnail for album: " + name, e);
            return null; // Return null if there is an error
        }
    }
    
}
