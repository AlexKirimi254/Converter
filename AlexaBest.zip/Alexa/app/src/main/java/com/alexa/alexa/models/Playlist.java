package com.alexa.alexa.models;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Represents a music playlist containing a list of SongItem objects.
 */
public class Playlist implements Comparable<Playlist>, Parcelable {

    private String id; // Unique identifier for the playlist
    private String name;
    private List<SongItem> songs;
    private long dateCreated;
    private long dateModified;
    private boolean isFavorite;
    private String iconPath; // Path to the playlist icon

    // Default Constructor
    public Playlist() {
        this.id = generateUniqueId();
        this.name = "";
        this.songs = Collections.synchronizedList(new ArrayList<SongItem>());
        this.dateCreated = System.currentTimeMillis();
        this.dateModified = this.dateCreated;
        this.isFavorite = false;
        this.iconPath = "";
    }

    // Parameterized Constructor
    public Playlist(String name) {
        this.id = generateUniqueId();
        this.name = name;
        this.songs = Collections.synchronizedList(new ArrayList<SongItem>());
        this.dateCreated = System.currentTimeMillis();
        this.dateModified = this.dateCreated;
        this.isFavorite = false;
        this.iconPath = "";
    }

    // Parcelable Constructor
    protected Playlist(Parcel in) {
        id = in.readString();
        name = in.readString();
        songs = Collections.synchronizedList(new ArrayList<SongItem>());
        in.readTypedList(songs, SongItem.CREATOR);
        dateCreated = in.readLong();
        dateModified = in.readLong();
        isFavorite = in.readByte() != 0;
        iconPath = in.readString();
    }

    /**
     * Generates a unique ID for the playlist using UUID.
     *
     * @return A unique string ID.
     */
    private String generateUniqueId() {
        return UUID.randomUUID().toString();
    }

    // Parcelable Implementation
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeTypedList(songs);
        dest.writeLong(dateCreated);
        dest.writeLong(dateModified);
        dest.writeByte((byte) (isFavorite ? 1 : 0));
        dest.writeString(iconPath);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Playlist> CREATOR = new Creator<Playlist>() {
        @Override
        public Playlist createFromParcel(Parcel in) {
            return new Playlist(in);
        }

        @Override
        public Playlist[] newArray(int size) {
            return new Playlist[size];
        }
    };

    // Comparable Implementation - Compare by playlist name
    @Override
    public int compareTo(Playlist other) {
        return this.name.compareToIgnoreCase(other.name);
    }

    // Getter and Setter Methods

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    /**
     * Sets the name of the playlist and updates the dateModified timestamp.
     *
     * @param name The new name of the playlist.
     */
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
            updateDateModified();
        }
    }

    public List<SongItem> getSongs() {
        return Collections.unmodifiableList(songs);
    }

    /**
     * Sets the list of songs in the playlist and updates the dateModified timestamp.
     *
     * @param songs The new list of SongItem objects.
     */
    public void setSongs(List<SongItem> songs) {
        if (songs != null) {
            synchronized (this.songs) {
                this.songs.clear();
                this.songs.addAll(songs);
            }
            updateDateModified();
        }
    }

    public long getDateCreated() {
        return dateCreated;
    }

    public long getDateModified() {
        return dateModified;
    }

    public boolean isFavorite() {
        return isFavorite;
    }

    /**
     * Sets the favorite status of the playlist and updates the dateModified timestamp.
     *
     * @param favorite True if the playlist is a favorite, false otherwise.
     */
    public void setFavorite(boolean favorite) {
        this.isFavorite = favorite;
        updateDateModified();
    }

    public String getIconPath() {
        return iconPath;
    }

    /**
     * Sets the icon path of the playlist and updates the dateModified timestamp.
     *
     * @param iconPath The new icon path.
     */
    public void setIconPath(String iconPath) {
        if (iconPath != null) {
            this.iconPath = iconPath;
            updateDateModified();
        }
    }

    /**
     * Adds a song to the playlist and updates the dateModified timestamp.
     *
     * @param song The SongItem to add.
     */
    public boolean addSong(SongItem song) {
        if (!songs.contains(song)) {
            songs.add(song);
            return true;
        }
        return false;
    }




    /**
     * Removes a song from the playlist and updates the dateModified timestamp.
     *
     * @param song The SongItem to remove.
     * @return True if the song was removed successfully, false otherwise.
     */
    public boolean removeSong(SongItem song) {
        if (song != null) {
            boolean removed;
            synchronized (songs) {
                removed = songs.remove(song);
            }
            if (removed) {
                updateDateModified();
            }
            return removed;
        }
        return false;
    }

    /**
     * Moves a song to a new position within the playlist and updates the dateModified timestamp.
     *
     * @param song        The SongItem to move.
     * @param newPosition The new position index.
     * @return True if the song was moved successfully, false otherwise.
     */
    public boolean moveSong(SongItem song, int newPosition) {
        if (song == null || newPosition < 0) {
            return false;
        }
        synchronized (songs) {
            int currentPosition = songs.indexOf(song);
            if (currentPosition == -1) {
                return false;
            }
            if (newPosition >= songs.size()) {
                newPosition = songs.size() - 1;
            }
            songs.remove(currentPosition);
            songs.add(newPosition, song);
        }
        updateDateModified();
        return true;
    }

    /**
     * Sorts the songs in the playlist alphabetically by title and updates the dateModified timestamp.
     */
    public void sortByTitle() {
        synchronized (songs) {
            Collections.sort(songs, new Comparator<SongItem>() {
                    @Override
                    public int compare(SongItem s1, SongItem s2) {
                        return s1.getTitle().compareToIgnoreCase(s2.getTitle());
                    }
                });
        }
        updateDateModified();
    }

    /**
     * Sorts the songs in the playlist by their duration (shortest to longest) and updates the dateModified timestamp.
     */
    public void sortByDuration() {
        synchronized (songs) {
            Collections.sort(songs, new Comparator<SongItem>() {
                    @Override
                    public int compare(SongItem s1, SongItem s2) {
                        return Long.compare(s1.getDuration(), s2.getDuration());
                    }
                });
        }
        updateDateModified();
    }

    /**
     * Shuffles the songs in the playlist randomly and updates the dateModified timestamp.
     */
    public void shuffle() {
        synchronized (songs) {
            Collections.shuffle(songs);
        }
        updateDateModified();
    }

    /**
     * Calculates and returns the total duration of all songs in the playlist in hh:mm:ss format.
     *
     * @return The formatted total duration string.
     */
    public String getFormattedTotalDuration() {
        long totalDuration = 0;
        synchronized (songs) {
            for (SongItem song : songs) {
                totalDuration += song.getDuration();
            }
        }
        long hours = totalDuration / 3600000;
        long minutes = (totalDuration % 3600000) / 60000;
        long seconds = (totalDuration % 60000) / 1000;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
    }

    /**
     * Updates the dateModified timestamp to the current time.
     */
    public void updateDateModified() {
        this.dateModified = System.currentTimeMillis();
    }

    /**
     * Creates a deep copy of the Playlist object.
     *
     * @return A new Playlist object with the same data.
     */
    public Playlist copy() {
        Playlist copy = new Playlist();
        copy.id = this.id;
        copy.name = this.name;
        synchronized (songs) {
            copy.songs.addAll(this.songs);
        }
        copy.dateCreated = this.dateCreated;
        copy.dateModified = this.dateModified;
        copy.isFavorite = this.isFavorite;
        copy.iconPath = this.iconPath;
        return copy;
    }

    /**
     * Debugging purpose: returns a string representation of the Playlist object.
     * This should not be used for UI display.
     */
    @Override
    public String toString() {
        return String.format(Locale.getDefault(),
                             "Playlist{id='%s', name='%s', songCount=%d, totalDuration=%s}",
                             id, name, songs.size(), getFormattedTotalDuration());
    }
}

