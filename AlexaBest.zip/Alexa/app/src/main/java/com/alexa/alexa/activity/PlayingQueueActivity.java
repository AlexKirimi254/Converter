package com.alexa.alexa.activity;


import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;

public class PlayingQueueActivity extends Activity {
    private ListView queueListView;
    private ArrayList<SongItem> songQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing_queue);

        queueListView = findViewById(R.id.queue_list_view);

        // Retrieve the song queue passed via intent
        songQueue = getIntent().getParcelableArrayListExtra("songQueue");

        // Set up the adapter to display the queued songs
        if (songQueue != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                getSongTitles(songQueue)
            );
            queueListView.setAdapter(adapter);
        }
    }

    private ArrayList<String> getSongTitles(ArrayList<SongItem> songQueue) {
        ArrayList<String> titles = new ArrayList<>();
        for (SongItem song : songQueue) {
            titles.add(song.getTitle());
        }
        return titles;
    }
}
