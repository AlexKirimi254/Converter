package com.alexa.alexa.tabs;

import android.content.SharedPreferences;
import android.view.View;
import android.widget.ListView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.SongsQueueAdapter;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.view.tabview.Tab;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class SongsQueueTab extends Tab {
    private View root;
    private MainActivity act;
    private ListView queueListView;
    private ArrayList<SongItem> songsQueue;
    private SongsQueueAdapter queueAdapter;
    private SharedPreferences sharedPreferences;
    private Gson gson;

    private static final String PREF_NAME = "SongQueuePrefs";
    private static final String QUEUE_KEY = "songs_queue";

    public SongsQueueTab(MainActivity act) {
        this.act = act;
        root = act.getLayoutInflater().inflate(R.layout.default_listview, null, false);

        // Initialize the SharedPreferences and Gson for storing/retrieving the queue
        sharedPreferences = act.getSharedPreferences(PREF_NAME, MainActivity.MODE_PRIVATE);
        gson = new Gson();

        // Initialize the ListView and ArrayList for the song queue
        queueListView = root.findViewById(R.id.list_view_list1);
        songsQueue = loadSongsQueue(); // Load the persisted queue

        // Create the custom adapter and set it to the ListView
        queueAdapter = new SongsQueueAdapter(act, songsQueue);
        queueListView.setAdapter(queueAdapter);
    }

    @Override
    public View getView() {
        return root;
    }

    // Method to add songs to the queue, only if they are not already present
    public void addSongToQueue(SongItem songItem) {
        if (!songsQueue.contains(songItem)) {  // Check if song is already in the queue
            songsQueue.add(songItem);
            queueAdapter.notifyDataSetChanged(); // Update the ListView with new data
            saveSongsQueue(); // Save the updated queue to SharedPreferences
        }
    }

    // Method to save the song queue in SharedPreferences as JSON
    private void saveSongsQueue() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        String json = gson.toJson(songsQueue); // Convert ArrayList to JSON string
        editor.putString(QUEUE_KEY, json);
        editor.apply();
    }

    // Method to load the song queue from SharedPreferences
    private ArrayList<SongItem> loadSongsQueue() {
        String json = sharedPreferences.getString(QUEUE_KEY, null);
        if (json != null) {
            Type type = new TypeToken<ArrayList<SongItem>>() {}.getType();
            return gson.fromJson(json, type); // Convert JSON string back to ArrayList
        }
        return new ArrayList<>(); // Return an empty list if no saved queue exists
    }

    // Call this method when you want to clear the queue (optional)
    public void clearQueue() {
        songsQueue.clear();
        queueAdapter.notifyDataSetChanged();
        saveSongsQueue(); // Clear the saved queue in SharedPreferences
    }
}
