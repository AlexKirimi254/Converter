package com.alexa.alexa.menu;


import android.app.Dialog;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.models.SongItem;
import android.content.Context;

public class PlaylistSongOptions implements View.OnClickListener {
    private Context ctx;
    private SongItem si;
    private Dialog dlg;
    private TextView title, artist;
    private MainActivity act;
    public PlaylistSongOptions(Context ctx, SongItem si) {
        this.ctx = ctx;
        this.si = si;
        dlg = new Dialog(ctx);
        dlg.requestWindowFeature(Dialog.BUTTON1);
        dlg.setContentView(R.layout.dlg_songitem_options);

        // Initialize UI elements
        title = (TextView) dlg.findViewById(R.id.popup_auplayer_songoptions_title);
        artist = (TextView) dlg.findViewById(R.id.popup_auplayer_songoptions_artist);

        // Set song details
        title.setText(si.title);
        artist.setText(si.artist);

        // Set up option click listeners
        LinearLayout ops = (LinearLayout) dlg.findViewById(R.id.popup_auplayer_songoptions_clk);
        int cc = ops.getChildCount();
        for (int i = 0; i < cc; i++) {
            ops.getChildAt(i).setOnClickListener(this);
        }
    }

    public void show() {
        dlg.show();
    }

    public void hide() {
        dlg.dismiss();
        title.setText("");
        artist.setText("");
        si = null;
    }

    @Override
    public void onClick(View v) {
        if (v.getTag() != null) {
            String tag = v.getTag().toString();
            if (tag != null) {
                tag = tag.split(" ")[0];
            }
            switch (tag) {
                case "playnext":
                    act.addToQueue(si);  // Method in MainActivity to add the song to the queue
                    break;
                case "addtoplaylist":
                    act.showAddToPlaylistDialog(si); // Method to show dialog for adding to playlist
                    break;
                case "editfiletags":
                    act.showEditFileTagsDialog(si); // Method to edit file tags
                    break;
                case "deletesong":
                    act.confirmDeleteSong(si); // Method to confirm deletion of the song
                    break;
                default:
                    break;
            }
        }
        hide();
    }
}
