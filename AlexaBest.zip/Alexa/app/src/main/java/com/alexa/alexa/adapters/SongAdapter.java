package com.alexa.alexa.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SongAdapter extends BaseAdapter {

    private Context context;
    private List<SongItem> allSongs;
    private List<SongItem> selectedSongs;
    private Set<Integer> selectedPositions;

    public SongAdapter(Context context, List<SongItem> allSongs, List<SongItem> selectedSongs) {
        this.context = context;
        this.allSongs = allSongs;
        this.selectedSongs = selectedSongs;
        this.selectedPositions = new HashSet<>();

        // Initialize selected positions based on selectedSongs
        for (int i = 0; i < allSongs.size(); i++) {
            if (selectedSongs.contains(allSongs.get(i))) {
                selectedPositions.add(i);
            }
        }
    }

    @Override
    public int getCount() {
        return allSongs.size();
    }

    @Override
    public Object getItem(int position) {
        return allSongs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    // ViewHolder pattern for better performance
    private static class ViewHolder {
        TextView songName;
        CheckBox checkBox;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.adapteritem_song, parent, false);
            holder = new ViewHolder();
            holder.songName = convertView.findViewById(R.id.song_name);
            holder.checkBox = convertView.findViewById(R.id.song_checkbox);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final SongItem song = allSongs.get(position);
        holder.songName.setText(song.getTitle());

        holder.checkBox.setOnCheckedChangeListener(null); // Reset listener to avoid recycling issues
        holder.checkBox.setChecked(selectedPositions.contains(position));

        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        selectedPositions.add(position);
                        selectedSongs.add(song);
                    } else {
                        selectedPositions.remove(position);
                        selectedSongs.remove(song);
                    }
                }
            });

        return convertView;
    }
}
