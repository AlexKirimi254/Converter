package com.alexa.alexa.adapters;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.models.AlbumItem;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.models.SongItem;
import java.util.List;
import android.view.LayoutInflater;

public class AlbumsListAdaptor extends BaseAdapter {

    private Context context;
    private List<AlbumItem> songList;

    private SongItem currentSong;

    private ThemeManager.Theme theme;

    public AlbumsListAdaptor(Context context, List<AlbumItem> songList) {
        this.context = context;
        this.songList = songList;
    }
    public void update(List<AlbumItem> list) {
        songList = list;
        notifyDataSetChanged();
    }

    // Set the theme for the adapter
    public void setTheme(ThemeManager.Theme theme) {
        this.theme = theme;
    }
    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public AlbumItem getItem(int position) {
        return songList.get(position);
    }
    public void setCurrentSong(SongItem song) {
        this.currentSong = song;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
/*
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        AlbumItem artist = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(parent(R.layout.adapteritem_artist, parent, false);
        }

        TextView nameTextView = convertView.findViewById(R.id.artistlist_itemTitle);
        TextView countTextView = convertView.findViewById(R.id.artistlist_songcount);
        ImageView thumbnailImageView = convertView.findViewById(R.id.artistlist_item_albumart); // Assuming you have an ImageView for the thumbnail

        nameTextView.setText(artist.getName());
        countTextView.setText(artist.getSongcount() + (artist.getSongcount() > 1 ? " songs" : " song"));

        // Load the artist's thumbnail if available
        Bitmap thumbnail = artist.getThumbnail(); // Assuming this method exists
        if (artist.getName() != null) {
            thumbnailImageView.setImageDrawable(new BitmapDrawable(parent.getResources(), artist.getThumbnail()));
        } else {
            // Optionally, you can set a default thumbnail
            //thumbnailImageView.setImageResource(R.drawable.cover_f); // Placeholder image
        }

        // Apply theme colors
        if (theme != null) {
            nameTextView.setTextColor(theme.text);
            countTextView.setTextColor(theme.text);
            // convertView.setBackgroundColor(theme.background);
        }

        // Set the click listener for the item
        convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ArtistItem clickedArtist = getItem(position);
                    if (itemClickListener != null) {
                        itemClickListener.onItemClick(clickedArtist);
                    }
                }
            });

        return convertView;
    }


*/


@Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.adapteritem_album, parent, false);
        }

        AlbumItem song = getItem(position);

        TextView titleView = (TextView) convertView.findViewById(R.id.albumlist_itemTitle);
        TextView artistView = (TextView) convertView.findViewById(R.id.albumlist_songcount);
        ImageView thumbnailImageView = convertView.findViewById(R.id.albumlist_item_albumart); // Assuming you have an ImageView for the thumbnail
    
        titleView.setText(song.getAlbumName());
        artistView.setText((song.getAlbumCount() > 1 ? " songs" : " song"));
        
        
        
    // Apply theme colors
    if (theme != null) {
        titleView.setTextColor(theme.background);
        artistView.setTextColor(theme.text);
        convertView.setBackgroundColor(theme.background);
    }
    if (song.getAlbumName() != null) {
        thumbnailImageView.setImageDrawable(new BitmapDrawable(parent.getResources(), song.getThumbnail()));
    } else {
        // Optionally, you can set a default thumbnail
        //thumbnailImageView.setImageResource(R.drawable.cover_f); // Placeholder image
    }
    
        
        return convertView;
    }
    
    
    
    
    }
