package com.alexa.alexa.ActivityAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.List;

public class PlaylistsActivitySongsAdapter extends BaseAdapter {
    private List<SongItem> songs;
    private LayoutInflater inflater;

    public PlaylistsActivitySongsAdapter(Context context, List<SongItem> songs) {
        this.songs = songs;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return songs.size();
    }

    @Override
    public Object getItem(int position) {
        return songs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    // ViewHolder pattern for efficient view recycling
    private static class ViewHolder {
        TextView titleView;
        TextView artistView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        // Inflate the view and initialize the ViewHolder
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.songlist_item, parent, false);
            holder = new ViewHolder();
            holder.titleView = (TextView) convertView.findViewById(R.id.songlist_itemTitle);
            holder.artistView = (TextView) convertView.findViewById(R.id.songlist_itemArtist);
            convertView.setTag(R.id.view_holder, holder); // Use unique key for ViewHolder
        } else {
            holder = (ViewHolder) convertView.getTag(R.id.view_holder);
        }

        // Get the current SongItem
        SongItem song = songs.get(position);

        // Bind data to the views
        holder.titleView.setText(song.getTitle());
        holder.artistView.setText(song.getArtist());

        // Set the SongItem as a tag on the convertView for retrieval in the onItemClickListener
        convertView.setTag(R.id.song_item, song); // Use unique key for SongItem

        return convertView;
    }
}
