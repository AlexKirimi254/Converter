package com.alexa.alexa.menu;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.models.Playlist;

import com.alexa.alexa.models.SongItem;
import java.util.List;
/*
public class PlaylistTabDialog extends Dialog implements AdapterView.OnItemClickListener, View.OnClickListener
 {

    private Context ctx;
    private SongItem songItem;
    private ListView playlistListView;
    private Button createNewPlaylistButton;
    private PlaylistAdapter playlistAdapter;
    private List<Playlist> playlists;

    public PlaylistTabDialog(Context context, Playlist songItem) {
        super(context);
        this.ctx = context;
       // this.songItem = songItem;

        // Ensure the context is an instance of MainActivity
        if (context instanceof MainActivity) {
            // You can perform additional initialization if needed
        } else {
            throw new IllegalArgumentException("Context must be an instance of MainActivity");
        }

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_add_to_playlist);

        playlistListView = findViewById(R.id.playlist_list_view);
        createNewPlaylistButton = findViewById(R.id.create_new_playlist_button);

        // Initialize PlaylistManager and fetch playlists
        PlaylistManager playlistManager = PlaylistManager.getInstance(ctx);
        playlists = playlistManager.getPlaylists();

        // Initialize PlaylistAdapter with the fetched playlists
        playlistAdapter = new PlaylistAdapter(ctx, playlists);
        playlistListView.setAdapter(playlistAdapter);
        playlistListView.setOnItemClickListener(this);

        createNewPlaylistButton.setOnClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Playlist selectedPlaylist = (Playlist) parent.getItemAtPosition(position);
        PlaylistManager playlistManager = PlaylistManager.getInstance(ctx);
        boolean success = playlistManager.addSongToPlaylist(selectedPlaylist, songItem);

        if (success) {
            Toast.makeText(ctx, "Added to " + selectedPlaylist.getName(), Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ctx, "Failed to add to " + selectedPlaylist.getName(), Toast.LENGTH_SHORT).show();
        }

        dismiss();  // Close the dialog after adding the song to the playlist
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.create_new_playlist_button) {
            //new CreatePlaylistDialog(ctx, songItem, this).show();
        }
    }

    // Method to refresh the playlist list when a new playlist is created
    public void refreshPlaylists() {
        PlaylistManager playlistManager = PlaylistManager.getInstance(ctx);
        playlists.clear();
        playlists.addAll(playlistManager.getPlaylists());
        playlistAdapter.notifyDataSetChanged();
    }
}*/
