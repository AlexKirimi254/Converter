package com.alexa.alexa;
import android.os.Handler;
import android.os.Looper;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.service.AudioService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class App
{
    public static int REQUEST_CODE_AUDIOSERVICE = 300;
    public static int REQUEST_CODE_ = 301;
    
    private static volatile App deft;
    
    private AudioService aupod;
    
    private MainActivity mainactt;
    
    private static Handler handle = new Handler(Looper.getMainLooper());
    
    private AudioService.ConnectionListener connl;
    
    ExecutorService worker;
    
    private App(){
        worker = Executors.newFixedThreadPool(2);
    }
    
    public static App get(){
        App inst = deft;
        if(inst==null){
            synchronized(App.class){
                inst = App.deft;
                if(inst==null){
                    inst = App.deft = new App();
                }
            }
        }
        return inst;
    }
    
    public void setMainActivity(MainActivity act){
        mainactt = act;
    }
    
    public void toast(String msg){
        if(mainactt!=null){
            mainactt.toast(msg);
        }
    }
    
    public MainActivity getMainActivity(){
        return mainactt;
    }
    
    public static String getAppDirectory(){
        return "/sdcard/.sleepchild/aupod/";
    }
    
    public static void runInBackground(Runnable task){
        //new Thread(task).start();
        get().worker.submit(task);
    }
    
    public static void runInUiThread(Runnable task){
        handle.post(task);
    }
    
    public void registerAudiosService(AudioService service){
        aupod = service;
    }
    
    public AudioService getAudioService(){
        return aupod;
    }
    
    public AudioService.ConnectionListener getConnl(){
        AudioService.ConnectionListener c = connl;
        connl = null;
        return c;
    }
    
    public void setConnl(AudioService.ConnectionListener temp){
        connl = temp;
    }
}
