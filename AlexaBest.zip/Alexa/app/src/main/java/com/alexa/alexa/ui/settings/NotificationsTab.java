package com.alexa.alexa.ui.settings;
import android.view.View;
import com.alexa.alexa.activity.SettingsActivity;

public class NotificationsTab extends SettingsTab
{
    public NotificationsTab(SettingsActivity act){
        super(act);
    }

    @Override
    public View getView()
    {
        return null;
    }

    
    
}
