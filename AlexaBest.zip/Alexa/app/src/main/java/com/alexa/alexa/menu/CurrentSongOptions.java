package com.alexa.alexa.menu;

import android.app.Activity;
import android.app.Dialog;
import android.view.Window;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;

public class CurrentSongOptions
{
    Activity act;
    SongItem si;
    
    Dialog dlg;
    
    public CurrentSongOptions(Activity ctx, SongItem song){
        this.act = ctx;
        this.si = song;
        //
        dlg = new Dialog(ctx);
        dlg.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        dlg.setContentView(R.layout.dlg_auplayer_options);
    }
    
    public void show(){
        dlg.show();
    }
    
    public void dismiss(){
        dlg.dismiss();
    }
}
