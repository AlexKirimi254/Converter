package com.alexa.alexa.library;

import com.alexa.alexa.APEvents;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QueueManager
 {
    private final List<SongItem> queue = new ArrayList<>();
    private final Object lock = new Object();
    private final APEvents events;

    public QueueManager(APEvents events) {
        this.events = events;
    }

    // Enqueue a single song
    public void enqueueSong(SongItem song) {
        if (song != null) {
            synchronized(lock) {
                queue.add(song);
                events.postSongsListUpdated(queue);
            }
        }
    }

    // Enqueue multiple songs
    public void enqueueSongs(List<SongItem> songs) {
        if (songs != null && !songs.isEmpty()) {
            synchronized(lock) {
                queue.addAll(songs);
                events.postSongsListUpdated(queue);
            }
        }
    }

    // Insert a song at a specific position
    public void insertSong(SongItem song, int position) {
        if (song != null && position >= 0 && position <= queue.size()) {
            synchronized(lock) {
                queue.add(position, song);
                events.postSongsListUpdated(queue);
            }
        }
    }

    // Remove a song from the queue
    public boolean removeSong(SongItem song) {
        if (song != null) {
            synchronized(lock) {
                boolean removed = queue.remove(song);
                if (removed) {
                    events.postSongsListUpdated(queue);
                }
                return removed;
            }
        }
        return false;
    }

    // Clear the entire queue
    public void clearQueue() {
        synchronized(lock) {
            queue.clear();
            events.postSongsListUpdated(queue);
        }
    }

    // Move a song within the queue
    public boolean moveSong(int fromPosition, int toPosition) {
        synchronized(lock) {
            if (fromPosition < 0 || toPosition < 0 || 
                fromPosition >= queue.size() || toPosition >= queue.size()) {
                return false;
            }
            SongItem song = queue.remove(fromPosition);
            queue.add(toPosition, song);
            events.postSongsListUpdated(queue);
            return true;
        }
    }

    // Get the current queue (read-only)
    public List<SongItem> getQueue() {
        synchronized(lock) {
            return Collections.unmodifiableList(new ArrayList<>(queue));
        }
    }

    // Get the next song in the queue
    public SongItem getNextSong(SongItem currentSong) {
        synchronized(lock) {
            if (queue.isEmpty()) return null;
            int idx = queue.indexOf(currentSong);
            if (idx == -1 || idx + 1 >= queue.size()) {
                // Optionally loop to the first song
                return queue.get(0);
            }
            return queue.get(idx + 1);
        }
    }

    // Get the previous song in the queue
    public SongItem getPreviousSong(SongItem currentSong, boolean restartCurrentOnPrev) {
        synchronized(lock) {
            if (queue.isEmpty()) return null;
            int idx = queue.indexOf(currentSong);
            if (idx <= 0) {
                return queue.get(0); // or return null to indicate no previous song
            }
            return queue.get(idx - 1);
        }
    }
}
