package com.alexa.alexa.ActivityAdapters;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.List;

public class AlbumsActivitySongsAdapter extends BaseAdapter {

    private Context context;
    private List<SongItem> songList;

    private SongItem currentSong;

    public AlbumsActivitySongsAdapter(Context context, List<SongItem> songList) {
        this.context = context;
        this.songList = songList;
    }

    @Override
    public int getCount() {
        return songList.size();
    }

    @Override
    public Object getItem(int position) {
        return songList.get(position);
    }
    public void setCurrentSong(SongItem song) {
        this.currentSong = song;
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.songlist_item, parent, false);
        }

        SongItem song = songList.get(position);

        TextView titleView = (TextView) convertView.findViewById(R.id.songlist_itemTitle);
        TextView artistView = (TextView) convertView.findViewById(R.id.songlist_itemArtist);

        titleView.setText(song.getTitle());
        artistView.setText(song.getArtist());
        if (currentSong != null && song.equals(currentSong)) {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.colorPrimary));
        } else {
            convertView.setBackgroundColor(context.getResources().getColor(R.color.abc_background_cache_hint_selector_material_light));
        }
        return convertView;
    }
}
