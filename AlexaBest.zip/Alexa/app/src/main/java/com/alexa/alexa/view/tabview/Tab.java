package com.alexa.alexa.view.tabview;

import android.view.View;
import com.alexa.alexa.ThemeManager;

//todo: this should be an interface?
public abstract class Tab{
    
    public Tab(){}

    public abstract View getView();

    public void onTabShown(){}

    public void onTabHidden(){}

    public void onTabAlreadyVisible(){}
    
    public void onApplyTheme(ThemeManager.Theme theme){}

}
