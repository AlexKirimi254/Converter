package com.alexa.alexa.service;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.Equalizer;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.XApp;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.recievers.ButtonReciever;
import com.alexa.alexa.utils.Notific;
import com.alexa.alexa.utils.SPrefs;
import com.alexa.alexa.utils.Utils;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AudioService extends Service{

    private static String TAG = "AudioService";
    public static final String CMD_START = "com.alexa.alexa.service.cmd.start_service";
    public static final String CMD_END = "com.alexa.alexa.service.cmd.end.exit";
    public static final String CMD_MEDIA_BUTTON = "com.alexa.alexa.service.CMD_MEDIA_BUTTON";
    //
    public static final String CMD_PAUSE = "com.alexa.alexa.service.CMD_PAUSE";
    public static final String CMD_PLAY = "com.alexa.alexa.service.CMD_PLAY";
    public static final String CMD_PLAY_NEXT = "com.alexa.alexa.service.CMD_PLAY_NEXT";
    public static final String CMD_PLAY_PREV = "com.alexa.alexa.service.CMD_PLAY_PREV";
	//
    private final int NID = 5374;
    //
    private Context ctx;
    private MediaPlayer mPlayer;
    private AudioManager am;
    private PowerManager.WakeLock wakelock;
    private ComponentName mediaButtonComponent;
    SPrefs prefs;
	private List<SongItem> songQueue;

    private SongItem currentSong;
    private Handler handle = new Handler();
	private final IBinder binder = new LocalBinder();
    private boolean restartCurrentOnPrev = true;
    private boolean songset = false;
    boolean recieversRegistered = false;
	private int currentSongIndex;
    private List<SongItem> songlist = new ArrayList<>();

	private ArrayList<SongItem> currentPlaylist;
	private static AudioService instance;
	private boolean isShuffleEnabled = false;
    private RepeatMode repeatMode = RepeatMode.NONE;
    private boolean songSet = false;

	public static final int NOTIFICATION_ID = 0;

	

    public enum RepeatMode {
        NONE, REPEAT_ONE, REPEAT_ALL
        }


    private ArrayList<ServiceQueueListener> listeners = new ArrayList<>();

    public enum PlaybackMode {
        PLAY_ALL,
        SHUFFLE,
        QUEUE
        }

	private Equalizer equalizer;
    private PlaybackMode currentMode;
    private List<SongItem> defaultSongList; // To hold the original list of songs
	
    @Override
    public IBinder onBind(Intent p1) {
        return null;
    }
	public interface ServiceQueueListener {
		void onQueueUpdated(ArrayList<SongItem> updatedQueue);
	}
    @Override
    public void onCreate(){
        super.onCreate();
        ctx = getApplicationContext();
        prefs = new SPrefs(ctx);
        restartCurrentOnPrev = prefs.getRestartSongOnPrev();
        initMPlayer();
        //
		int sessionId = mPlayer.getAudioSessionId();
		initializeEqualizer(sessionId);
	
		songQueue = new ArrayList<>();
        am = (AudioManager) getSystemService(AUDIO_SERVICE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakelock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, TAG);
        //
        App.get().registerAudiosService(this);

    }
		

		private void initializeEqualizer(int audioSessionId) {
			equalizer = new Equalizer(0, audioSessionId);
			equalizer.setEnabled(true);  // Enable the equalizer

			// Example of setting custom band levels
			short numBands = equalizer.getNumberOfBands();
			for (short i = 0; i < numBands; i++) {
				equalizer.setBandLevel(i, (short) 0);  // Set all bands to flat (0)
			}

			// Optionally, use a preset
			equalizer.usePreset((short) 0); // 0 represents the first preset
		}

		
	
    @Override
    public void onDestroy()
    {if (equalizer != null) {
			equalizer.release();  // Release when no longer needed
		}
        unregisterRecievers();
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        if(intent!=null){
            String cmd = intent.getAction();
            switch(cmd){
                case CMD_START:
                    cmd_start();
                    break;
                case CMD_END:
                    cmd_end();
                    break;
                case CMD_PLAY:
                    resume();
                    break;
                case CMD_PAUSE:
                    pause();
                    break;
                case CMD_PLAY_NEXT:
                    playNext();
                    break;
                case CMD_PLAY_PREV:
                    playPrev();
                    break;
                case CMD_MEDIA_BUTTON:
                    handleMediabtn();
                    break;
            }
        }
        return START_NOT_STICKY;
    }
	public AudioService() {
		mPlayer = new MediaPlayer();
		songQueue = new ArrayList<>();
		currentSongIndex = -1;
		mPlayer = new MediaPlayer();
		songlist = new ArrayList<>();
		songQueue = new ArrayList<>();
		defaultSongList = new ArrayList<>();
		currentMode = PlaybackMode.PLAY_ALL; // Default mode
		mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					playNext();
				}
			});


/*
		mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					if (!isPlaying()) {
						// If playNext returns false, that means we ran out of songs
						currentMode = PlaybackMode.PLAY_ALL; // Reset to default mode
						currentSong = defaultSongList.get(0); // Optionally start from the first song
						playSong(currentSong);
					}
				}
			}); */
	}
	
	
	public void playPrevious() {
		if (currentSongIndex > 0) {
			currentSongIndex--;
		} else if (repeatMode == RepeatMode.REPEAT_ALL) {
			currentSongIndex = songQueue.size() - 1;
		}
		playSong(songQueue.get(currentSongIndex));
	}

	public void addToQueue(SongItem songItem) {
		songQueue.add(songItem);
		if (currentSongIndex == -1) {
			playSong(songItem);
		}
	}

	public void removeFromQueue(SongItem songItem) {
		int index = songQueue.indexOf(songItem);
		if (index == currentSongIndex) {
			playNext();
		}
		songQueue.remove(songItem);
	}

	public void clearQueue() {
		songQueue.clear();
		stopPlayback();
	}

	private void stopPlayback() {
		if (mPlayer.isPlaying()) {
			mPlayer.stop();
		}
		currentSongIndex = -1;
		songSet = false;
		stopNotification();
	}

	
	public void toggleShuffle() {
		isShuffleEnabled = !isShuffleEnabled;
		if (isShuffleEnabled) {
			Collections.shuffle(songQueue);
		} else {
			Collections.sort(songQueue); // Assuming songQueue has a natural order or can be sorted.
		}
	}

	
	public void playAll(SongItem songItem) {
        try {
            mPlayer.reset();
            mPlayer.setDataSource(songItem.path);
            mPlayer.prepare();
            mPlayer.start();
            restartCurrentOnPrev=prefs.getRestartSongOnPrev();
            int s=songlist.indexOf(0);
            songQueue.add(songItem);
            currentSongIndex = songQueue.indexOf(s);
            APEvents.getInstance().postSongChangeEvent(currentSong);
            APEvents.getInstance().postPlayStateEvent_start();

            showNotification();
            registerRecievers();  


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void shuffleAll() {
        if (songlist == null || songlist.isEmpty()) {
            return;
        }

        // Clear the current queue
        songQueue.clear();

        // Add all songs to the queue
        songQueue.addAll(songlist);

        // Shuffle the queue
        Collections.shuffle(songQueue);

        // Start playing from the first song in the shuffled queue
        currentSongIndex = 0;
        playSong(songQueue.get(currentSongIndex));
    }
    /*
	 public void addToQueue(SongItem songItem) {
	 songQueue.add(songItem);
	 if (currentSongIndex == -1) {
	 // Start playing immediately if no song is playing
	 playSong(songItem);
	 }
	 }*/
	
	
	public int getQueueSize() {
		return songQueue.size();
	}

	public List<SongItem> getQueue() {
		return songQueue;
	}
	
	
    public static void end(Context ctx){
        Intent si = new Intent(ctx, AudioService.class);
        si.setAction(CMD_END);
        ctx.startService(si);
    }

    public static void connect(Context ctx, ConnectionListener listener){
        App.get().setConnl(listener);
        Intent si = new Intent(ctx, AudioService.class);
        si.setAction(CMD_START);
        ctx.startService(si);
    }

    public static void playFromIntent(Context context, String songpath){
        //
    }

    public void onActivityDestroyed(){
        if(!isPlaying()){
            cmd_end();
        }
    }

    public void getSongsList(){
        SongLibrary.getInstance().getAllSongs(this, getsonglistresult);
    }

    // sets and plays the specified song
    public void playSong(SongItem si){
        if(si==null || mPlayer==null){
            return;
        }
        mPlayer.stop();
        mPlayer.reset();
        currentSong = si;
        prefs.saveLastPath(si.path);
        try
        {
            mPlayer.setDataSource(si.path);
            songset = true;
            mPlayer.prepare();
            resume();

            APEvents.getInstance().postSongChangeEvent(currentSong);
            APEvents.getInstance().postPlayStateEvent_start();
        }
        catch (IllegalArgumentException e)
        {}
        catch (IllegalStateException e)
        {}
        catch (SecurityException e)
        {}
        catch (IOException e)
        {}

    }

    // sets the specified song as current but does bot play it
    public void setSong(SongItem si){
        currentSong = si;
        try
        {
            mPlayer.setDataSource(si.path);
            mPlayer.prepare();
            songset = true;
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
        catch (IllegalArgumentException e){}
        catch (IllegalStateException e){}
        catch (IOException e){}
        catch (SecurityException e){}
    }

    public void playPause(){
        if(currentSong!=null){
            if(isPlaying()){
                pause();
            }else{
                if(songset){
                    resume();
                }else{
                    playSong(currentSong);
                }
            }
        }else{
            if(!songlist.isEmpty()){
                currentSong = songlist.get(0);
                if(currentSong!=null){
                    playSong(currentSong);
                }else{
                    // maybe the list is still loading.
                }
            }
        }

    }
	    public void pause(){
        mPlayer.pause();
        //
        stopNotification();
        releaseWakeLock();
        APEvents.getInstance().postPlayStateEvent_pause();
    }

    public void resume(){
        try{
            mPlayer.start();
            APEvents.getInstance().postPlayStateEvent_start();
            //
            showNotification();
            registerRecievers();

        }catch(Exception e){
            //
            toast(e.getMessage());
        }
    }

    public void stop(){
        mPlayer.stop();
        mPlayer.reset();
        //
        stopNotification();
        unregisterRecievers();
        APEvents.getInstance().postPlayStateEvent_stop();
    }

    public boolean playNext(){
        if(songlist.isEmpty()){
            return false;
        }
        boolean songChanged=false;
        int idx = songlist.indexOf(currentSong);
        int m = songlist.size()-1;
        idx++;
        if(idx>m){
            idx=m;
        }else{
            mPlayer.stop();
            mPlayer.reset();
            currentSong = songlist.get(idx);
            playSong(currentSong);
            songChanged=true;
        }
        return songChanged;
    }

    public void playPrev(){
        if(songlist.isEmpty()){
            return;
        }
        int idx = songlist.indexOf(currentSong);
        idx--;
        if(idx<0){
            idx = 0;
        }
        boolean rest= false;

        if(restartCurrentOnPrev){
            int ct = mPlayer.getCurrentPosition();
            if(ct>6000){
                rest=true;
            }
        }

        if(rest){
            mPlayer.seekTo(0);
        }else{
            mPlayer.stop();
            mPlayer.reset();
            currentSong = songlist.get(idx);
            playSong(currentSong);
        }
    }
	public void playSongsFromPlaylist(List<SongItem> playlist, int startIndex) {
		if (playlist == null || playlist.isEmpty()) {
			return;
		}

		songQueue = playlist;
		currentSongIndex = startIndex;
		playSong(currentSongIndex);  // Play the song at the given startIndex
	}
	
	private void playSong(int index) {
		if (currentPlaylist == null || index < 0 || index >= currentPlaylist.size()) {
			return;
		}

		SongItem song = currentPlaylist.get(index);
		// Logic to play the song (MediaPlayer, ExoPlayer, etc.)
	}
	
    public boolean isPlaying(){
        return mPlayer.isPlaying();
    }

    public SongItem getCurrentSong(){
        return currentSong;
    }

    public int getCurrentPosition(){
        return mPlayer.getCurrentPosition();
    }

    public int getDuration(){
        return mPlayer.getDuration();
    }

    public void seekTo(int pos){

        mPlayer.seekTo(pos);
    }

    public int getCurrentSongIndex(){
        if(currentSong==null){
            return 0;
        }
        if(!songlist.contains(currentSong)){
            return 0;
        }
        return songlist.indexOf(currentSong);
    }

    public void deleteSong(SongItem si){
        int m = songlist.size() - 1;
        if(currentSong==si){
            int i = getCurrentSongIndex();
            int n = i+1;
            if(n>m){
                n = i-1;
            }
            boolean ply = isPlaying();
            currentSong = songlist.get(n);
            playSong(currentSong);
            if(!ply){
                pause();
            }
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
        Utils.delete(si.path);
        getSongsList();
        Utils.toast(this,"song deleted!");
    }

    public void requestPlaystateUpdate(){
        if(mPlayer!=null){
            if(songset && currentSong!=null){
                APEvents.getInstance().postSongChangeEvent(currentSong);
            }

            if(mPlayer.isPlaying()){
                APEvents.getInstance().postPlayStateEvent_start();
            }
        }
    }
	public class LocalBinder extends Binder {
        public AudioService getService() {
            return AudioService.this;
        }
    }
	public void setPlaylist(ArrayList<SongItem> playlist, int startIndex) {
		this.currentPlaylist = playlist;
		this.currentSongIndex = startIndex;
	}
    ////////////////////
    ////  private  ////
    ///////////////////


    private SongLibrary.ResultCallback getsonglistresult = new SongLibrary.ResultCallback(){
        @Override
        public void onResult(final Object result){
            handle.post(new Runnable(){
					public void run(){
						List<SongItem> sl = (List<SongItem>) result;
						_ongetsongslist(sl);// delegate because 'this' refers to sth else in here.
					}
				});
        }
    };

    private void _ongetsongslist(List<SongItem> sl){
        boolean currentSongUpdated = false;
        boolean listChanged=false;

        if(songlist!=null){
            if(sl.containsAll(songlist) && songlist.containsAll(sl)){
                //
            }else{
                songlist = sl;
                listChanged = true;
            }
        }else{
            songlist = sl;
        }

        if(currentSong!=null){
            //if(listChanged){
			for(SongItem si : songlist){
				if(si.path.equalsIgnoreCase(currentSong.path)){
					currentSong = si;
					currentSongUpdated = true;
					break;
				}
			}
            //}

        }else{
            String p = prefs.getLastPath();
            if(Utils.exists(p)){
                for(SongItem si : songlist){
                    if(si.path.equalsIgnoreCase(p)){
                        currentSong = si;
                        break;
                    }
                }
                if(currentSong==null && !songlist.isEmpty()){
                    currentSong = songlist.get(0);
                }
            }else{
                if(!songlist.isEmpty()){
                    currentSong = songlist.get(0);
                }
            }
            //
        }

        if(!songset){
            if(currentSong!=null){
                setSong(currentSong);
                //mPlayer.start();
                //mPlayer.stop();
            }
        }

        if(songlist!=null){
            APEvents.getInstance().postSongsListUpdated(songlist);
        }
        //
        if(currentSong!=null){
            APEvents.getInstance().postSongChangeEvent(currentSong);
        }
    }

    private void cmd_start(){
        ConnectionListener l = App.get().getConnl();
        if(l!=null){
            l.onAudioServiceConnect(this);
        }
        // update notification theme
    }

    private void cmd_end(){

        stop();
        stopForeground(false);
        stopForeground(true);

        mPlayer.release();
        mPlayer = null;

        unregisterRecievers();

        stopSelf();

        XApp.exit();
        //
    }

    private void requestAudioFocus(){
        int af = am.requestAudioFocus(audioFocusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        if(af!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){
            toast("faild to get audio focus!");
        }
    }

    private void dropAudioFocus(){
        am.abandonAudioFocus(audioFocusListener);
    }

    boolean playingBeforePause=false;
    AudioManager.OnAudioFocusChangeListener audioFocusListener = new AudioManager.OnAudioFocusChangeListener(){
        @Override
        public void onAudioFocusChange(int state){
            switch(state){
                case AudioManager.AUDIOFOCUS_GAIN:
                    //resume();
                    //
                    break;
                case AudioManager.AUDIOFOCUS_GAIN_TRANSIENT:
                    //resume();
                    //
                    break;
                case AudioManager.AUDIOFOCUS_LOSS:
                    playingBeforePause = isPlaying();
                    pause();
                    unregisterRecievers();
                    dropAudioFocus();
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    playingBeforePause = isPlaying();
                    pause();
                    unregisterRecievers();
                    dropAudioFocus();
                    break;
            }
        }
    };

    // todo: try everything
    private void registerRecievers(){
        if(recieversRegistered){
            //return;
        }
        aquireWakeLock();
        requestAudioFocus();
        registerMediaButton();
        recieversRegistered = true;
        //
    }

    private void unregisterRecievers(){
        unRegisterMediaButton();
        dropAudioFocus();
        releaseWakeLock();
        recieversRegistered = false;
    }

    private void registerMediaButton(){
        try{
            if(mediaButtonComponent == null){
                mediaButtonComponent = new ComponentName(this, ButtonReciever.class.getName());
            }
            am.registerMediaButtonEventReceiver(mediaButtonComponent);
        }catch(Exception e){}
    }

    private void unRegisterMediaButton(){
        try{
            am.unregisterMediaButtonEventReceiver(mediaButtonComponent);
        }catch(Exception e){}
    }

    /// headsethook ~~ media button
    Runnable btnSingle = new Runnable(){
        public void run(){
            playPause();
            btnSinglepress = false;
        }
    };

    boolean btnSinglepress=false;;

    private void handleMediabtn(){
        if(btnSinglepress){
            handle.removeCallbacks(btnSingle);
            btnSinglepress = false;
            playNext();
        }else{
            btnSinglepress = true;
            handle.postDelayed(btnSingle, 280);
        }
    }

    private void aquireWakeLock(){
        try{
            if(wakelock!=null){
                wakelock.acquire();
                //Utils.toast(ctx, "wakeful: "+wakelock.isHeld());
            }
        }catch(Exception e){}
    }

    private void releaseWakeLock(){
        try{
            if(wakelock!=null){
                if(wakelock.isHeld()){
                    wakelock.release();
                }
            }
        }catch(Exception e){}
    }

    public void updateNotif(){}

    private void showNotification(){
        startForeground(NID, Notific.get(this, currentSong, true));
    }

    private void stopNotification(){
        startForeground(NID, Notific.get(this, currentSong, false));
    }

    private void initMPlayer(){
        mPlayer = new MediaPlayer();
        mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
				@Override
				public void onCompletion(MediaPlayer p1){
					playNext();
				}
			});
    }

    private void toast(String msg){
        Utils.toast(ctx,msg);
    }

    public interface ConnectionListener{
        public void onAudioServiceConnect(AudioService service);
    }



}
