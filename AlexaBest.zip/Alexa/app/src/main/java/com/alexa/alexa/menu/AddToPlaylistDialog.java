package com.alexa.alexa.menu;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.library.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import java.util.List;

/**
 * Dialog for adding a song to an existing playlist or creating a new playlist.
 */
public class AddToPlaylistDialog {

    private final Context context;
    private final PlaylistManager playlistManager;
    private final SongItem song;

    public AddToPlaylistDialog(Context context, SongItem song) {
        this.context = context;
        this.playlistManager = PlaylistManager.getInstance();
        this.song = song;
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Add to Playlist");

        // Inflate custom layout
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_add_to_playlist, null);
        builder.setView(view);

        final ListView playlistsListView = view.findViewById(R.id.listview_playlists);
        Button cancelButton = view.findViewById(R.id.button_cancel_add_to_playlist);
        Button createNewPlaylistButton = view.findViewById(R.id.button_create_new_playlist);

        final List<Playlist> playlists = playlistManager.getPlaylists();

        // Ensure that we pass MainActivity as context
        PlaylistAdapter adapter;
        if (context instanceof MainActivity) {
            adapter = new PlaylistAdapter((MainActivity) context, playlists);
        } else {
            Log.e("AddToPlaylistDialog", "Context is not an instance of MainActivity.");
            return;
        }

        playlistsListView.setAdapter(adapter);

        final AlertDialog dialog = builder.create();

        // Set OnItemClickListener for the ListView
        playlistsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view1, int position, long id) {
                Playlist selectedPlaylist = playlists.get(position);
                boolean added = playlistManager.addSongToPlaylist(selectedPlaylist.getName(), song);
                if (added) {
                    Toast.makeText(context, "Added to '" + selectedPlaylist.getName() + "'.", Toast.LENGTH_SHORT).show();
                    refreshPlaylistsTab();
                } else {
                    Toast.makeText(context, "Failed to add to '" + selectedPlaylist.getName() + "'.", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });

        // Set OnClickListener for the cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        // Set OnClickListener for the create new playlist button
        createNewPlaylistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCreateNewPlaylistDialog(dialog); // Pass current dialog to dismiss after creation
            }
        });

        dialog.show();
    }

    /**
     * Refreshes the PlaylistsTab if the context is an instance of MainActivity.
     */
    private void refreshPlaylistsTab() {
        if (context instanceof MainActivity) {
            ((MainActivity) context).refreshPlaylistsTab();
        } else {
            Log.e("AddToPlaylistDialog", "Context is not an instance of MainActivity. Cannot refresh PlaylistsTab.");
        }
    }
    
    
    private void showCreateNewPlaylistDialog(final AlertDialog parentDialog) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Create New Playlist");

        // Inflate custom layout for creating a new playlist
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_create_playlist, null);
        builder.setView(view);

        final EditText playlistNameInput = view.findViewById(R.id.edittext_playlist_name);
        Button createButton = view.findViewById(R.id.button_create_playlist);
        Button cancelButton = view.findViewById(R.id.button_cancel_create_playlist);

        final AlertDialog createDialog = builder.create();

        // Set OnClickListener for the create button
        createButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { 
                    String playlistName = playlistNameInput.getText().toString().trim();
                    if (!playlistName.isEmpty()) {
                        Playlist newPlaylist = playlistManager.createPlaylist(playlistName);
                        if (newPlaylist != null) {
                            boolean added = playlistManager.addSongToPlaylist(newPlaylist.getName(), song);
                            if (added) {
                                Toast.makeText(context, "Playlist '" + newPlaylist.getName() + "' created and song added.", Toast.LENGTH_SHORT).show();
                                refreshPlaylistsTab();
                            } else {
                                Toast.makeText(context, "Playlist created but failed to add song.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(context, "Failed to create playlist. It may already exist.", Toast.LENGTH_SHORT).show();
                        }
                        createDialog.dismiss();
                        parentDialog.dismiss(); // Dismiss the add to playlist dialog
                    } else {
                        Toast.makeText(context, "Playlist name cannot be empty.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        // Set OnClickListener for the cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { createDialog.dismiss(); }
            });

        createDialog.show();
    }
}
