package com.alexa.alexa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import com.alexa.alexa.R;
import com.alexa.alexa.service.AudioService;

public class IntentActivity extends BaseActivity{
    
    @Override
    public void onCreate(Bundle savedInstanceState){
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.iplayer);
        Intent i = getIntent();
        String path = clean(i.getDataString());
        //
        AudioService.playFromIntent(getApplicationContext(), path);
        
        //finish();
    }

    private String clean(String str){
        String cstr = str.replace("%20"," ");
        return cstr;
    }
    //
}
