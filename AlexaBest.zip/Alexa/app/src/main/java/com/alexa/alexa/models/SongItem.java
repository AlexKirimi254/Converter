package com.alexa.alexa.models;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import com.alexa.alexa.utils.BitmapUtils; // Ensure this import is included
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SongItem implements Comparable<SongItem>, Parcelable {

    public String id = "";
    public String title = "";
    public String artist = "";
    public String path = "";
    public String album = "";
    public long duration = 0;
    public boolean updated = false;
    public long artId;
    private int songcount;
    private String genre = "";
    private String lyrics = "";
    private String trackNumber = "";
    private String composer = "";
    private String mimeType = "";
    private String bitrate = "";
    private String albumArtist = "";
    private int year;
    private long dateAdded;
    private long ids;
    private String iconPath = "";  // Path to the album art icon

    // Default Constructor
    public SongItem() {}

    // Parcelable constructor
    protected SongItem(Parcel in) {
        id = in.readString();
        title = in.readString();
        artist = in.readString();
        path = in.readString();
        album = in.readString();
        duration = in.readLong();
        updated = in.readByte() != 0;
        artId = in.readLong();
        songcount = in.readInt();
        genre = in.readString();
        lyrics = in.readString();
        trackNumber = in.readString();
        composer = in.readString();
        mimeType = in.readString();
        bitrate = in.readString();
        albumArtist = in.readString();
        year = in.readInt();
        dateAdded = in.readLong();
        ids = in.readLong();
        iconPath = in.readString();  // Pass the icon path instead of Bitmap
    }

    // Parcelable implementation
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(title);
        dest.writeString(artist);
        dest.writeString(path);
        dest.writeString(album);
        dest.writeLong(duration);
        dest.writeByte((byte) (updated ? 1 : 0));
        dest.writeLong(artId);
        dest.writeInt(songcount);
        dest.writeString(genre);
        dest.writeString(lyrics);
        dest.writeString(trackNumber);
        dest.writeString(composer);
        dest.writeString(mimeType);
        dest.writeString(bitrate);
        dest.writeString(albumArtist);
        dest.writeInt(year);
        dest.writeLong(dateAdded);
        dest.writeLong(ids);
        dest.writeString(iconPath);  // Pass the icon path instead of Bitmap
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<SongItem> CREATOR = new Creator<SongItem>() {
        @Override
        public SongItem createFromParcel(Parcel in) {
            return new SongItem(in);
        }

        @Override
        public SongItem[] newArray(int size) {
            return new SongItem[size];
        }
    };

    // Comparable implementation - Compare by title, then artist if titles are equal
    @Override
    public int compareTo(SongItem other) {
        int titleComparison = this.title.compareToIgnoreCase(other.title);
        if (titleComparison == 0) {
            return this.artist.compareToIgnoreCase(other.artist);
        }
        return titleComparison;
    }

    // Getter and Setter methods for encapsulation
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getIconPath() {
        return iconPath;
    }

    public void setIconPath(String iconPath) {
        this.iconPath = iconPath;
    }

    // Getter methods for genre and year
    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }

    // Method to format duration in mm:ss format
    public String getFormattedDuration() {
        long minutes = duration / 60000;
        long seconds = (duration % 60000) / 1000;
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
    }

    // Method for deep copying the SongItem object
    public SongItem copy() {
        SongItem copy = new SongItem();
        copy.id = this.id;
        copy.title = this.title;
        copy.artist = this.artist;
        copy.path = this.path;
        copy.album = this.album;
        copy.duration = this.duration;
        copy.iconPath = this.iconPath;
        copy.updated = this.updated;
        copy.artId = this.artId;
        copy.songcount = this.songcount;
        copy.genre = this.genre;
        copy.lyrics = this.lyrics;
        copy.trackNumber = this.trackNumber;
        copy.composer = this.composer;
        copy.mimeType = this.mimeType;
        copy.bitrate = this.bitrate;
        copy.albumArtist = this.albumArtist;
        copy.year = this.year;
        copy.dateAdded = this.dateAdded;
        copy.ids = this.ids;
        return copy;
    }

    // Method to retrieve the thumbnail
    public Bitmap getThumbnail() {
        return BitmapUtils.getSongThumbnailFromFile(path);
    }

    @Override
    public String toString() {
        return String.format(Locale.getDefault(), "SongItem{id='%s', title='%s', artist='%s', album='%s', duration=%d}", 
                             id, title, artist, album, duration);
    }

    // Additional methods as needed...
}
