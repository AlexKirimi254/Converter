package com.alexa.alexa.activity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.database.DatabaseHelper; // Assuming you have a DatabaseHelper class

public class TagEditorActivity extends Activity {

    private EditText titleEditText, artistEditText, albumEditText, genreEditText, yearEditText;
    private DatabaseHelper dbHelper; // Database helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tageditor);

        // Initialize the views
        titleEditText = findViewById(R.id.activity_tageditor_title);
        artistEditText = findViewById(R.id.activity_tageditor_artist);
        albumEditText = findViewById(R.id.activity_tageditor_album);
        genreEditText = findViewById(R.id.activity_tageditor_genre);
        yearEditText = findViewById(R.id.activity_tageditor_year);

        // Initialize the DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Retrieve the song details from the intent
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String artist = intent.getStringExtra("artist");
        String album = intent.getStringExtra("album");
        String genre = intent.getStringExtra("genre");
        String year = intent.getStringExtra("year");

        // Set the values in the EditText fields
        titleEditText.setText(title);
        artistEditText.setText(artist);
        albumEditText.setText(album);
        genreEditText.setText(genre);
        yearEditText.setText(year);
    }

    private void saveTagInfo() {
        // Get the updated information from the EditText fields
        String updatedTitle = titleEditText.getText().toString();
        String updatedArtist = artistEditText.getText().toString();
        String updatedAlbum = albumEditText.getText().toString();
        String updatedGenre = genreEditText.getText().toString();
        String updatedYear = yearEditText.getText().toString();

        // Update the song info in the database
        // Replace "your_table_name" and "your_primary_key_column" with actual names
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", updatedTitle);
        values.put("artist", updatedArtist);
        values.put("album", updatedAlbum);
        values.put("genre", updatedGenre);
        values.put("year", updatedYear);

        // Assume you have the song ID passed through the intent to update the correct record
        long songId = getIntent().getLongExtra("song_id", -1);
        int rowsUpdated = db.update("your_table_name", values, "your_primary_key_column = ?", new String[]{String.valueOf(songId)});

        if (rowsUpdated >= 0) {
            Toast.makeText(this, "Tags saved successfully!", Toast.LENGTH_SHORT).show();

            // Optionally, finish the activity and return the updated information
            Intent resultIntent = new Intent();
            resultIntent.putExtra("updated_title", updatedTitle);
            resultIntent.putExtra("updated_artist", updatedArtist);
            resultIntent.putExtra("updated_album", updatedAlbum);
            resultIntent.putExtra("updated_genre", updatedGenre);
            resultIntent.putExtra("updated_year", updatedYear);
            setResult(RESULT_OK, resultIntent);
        } else {
            Toast.makeText(this, "Error saving tags!", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    public void onButton(View view) {
        // Handle button click for exiting the editor
        switch (view.getId()) {
            case R.id.activity_tageditor_exit:
                finish();
                break;
            case R.id.activity_tageditor_btn_save:
                saveTagInfo();
                break;
        }
    }
}
