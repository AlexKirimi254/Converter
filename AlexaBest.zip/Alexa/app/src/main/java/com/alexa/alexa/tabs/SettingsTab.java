package com.alexa.alexa.tabs;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import com.alexa.alexa.view.tabview.Tab;

public class SettingsTab extends Tab {

    private View tabView;

    public SettingsTab(Context context, int layoutResourceId) {
        // Inflate the tab's layout using the provided resource ID
        LayoutInflater inflater = LayoutInflater.from(context);
        tabView = inflater.inflate(layoutResourceId, null);
    }

    // Method to retrieve the view associated with the tab
    public View getView() {
        return tabView;
    }
}

