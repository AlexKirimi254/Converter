package com.alexa.alexa.tabs;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.PlaylistDetailsActivity;
import com.alexa.alexa.adapters.PlaylistAdapter;
import com.alexa.alexa.library.PlaylistManager;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.view.fastscroll.FastScrollListView;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.List;

/**
 * Tab class to display and manage playlists.
 */
public class PlaylistsTab extends Tab {

    private MainActivity ctx;
    private View root;
    private FastScrollListView list1;
    private List<Playlist> playlists;
    private PlaylistAdapter playlistAdapter;
    private PlaylistManager playlistManager;

    public PlaylistsTab(MainActivity act) {
        this.ctx = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_listview_playlist, null, false);
        list1 = root.findViewById(R.id.list_view_list1);

        playlistManager = PlaylistManager.getInstance();
        playlists = playlistManager.getPlaylists();
        playlistAdapter = new PlaylistAdapter(ctx, playlists);
        list1.setAdapter(playlistAdapter);

        // On item click, open PlaylistDetailsActivity
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Playlist selectedPlaylist = playlists.get(position);

                    if (selectedPlaylist.getSongs() == null || selectedPlaylist.getSongs().isEmpty()) {
                        Toast.makeText(ctx, "This playlist has no songs.", Toast.LENGTH_SHORT).show();
                    } else {
                        openPlaylistActivity(selectedPlaylist);
                    }
                }
            });
    }

    @Override
    public View getView() {
        return root;
    }

    private void openPlaylistActivity(Playlist selectedPlaylist) {
        Intent intent = new Intent(ctx, PlaylistDetailsActivity.class);
        intent.putExtra("PLAYLIST_NAME", selectedPlaylist.getName());
        intent.putParcelableArrayListExtra("PLAYLIST_SONGS", new ArrayList<>(selectedPlaylist.getSongs()));
        ctx.startActivity(intent);
    }

    public void refreshData() {
        playlists.clear();
        playlists.addAll(playlistManager.getPlaylists());
        playlistAdapter.notifyDataSetChanged();
    }
}
