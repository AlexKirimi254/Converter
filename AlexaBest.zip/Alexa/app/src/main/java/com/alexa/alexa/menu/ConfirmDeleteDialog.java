package com.alexa.alexa.menu;
//import android.content.*;
import android.app.AlertDialog;
import android.content.DialogInterface;
import com.alexa.alexa.App;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;

public class ConfirmDeleteDialog
{
    String path;
    MainActivity act;
    AlertDialog dlg;
    public ConfirmDeleteDialog(MainActivity ctx,final SongItem si){
       this.act = ctx; 
       String a = (si.artist=="<unknown>"? "": " - ")+si.artist;
       String msg = si.title+a;
       dlg = new AlertDialog.Builder(act)
           .setMessage(msg)
           .setPositiveButton("Delete", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    AudioService au = App.get().getAudioService();
                    if(au!=null){
                        au.deleteSong(si);
                    }
                    dlg.dismiss();
                }
            })
            .setNegativeButton("cancel", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    dlg.dismiss();
                }
            })
           .create();
       //dlg.getWindow().setBackgroundDrawableResource(R.color.pluto);
       dlg.setTitle("Are you sure to delete");
       //dlg.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
       //
    }
    
    public void show(){
        dlg.show();
    }
}
