package com.alexa.alexa.menu;




import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.alexa.alexa.R;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.library.PlaylistManager;


/**
 * Dialog for confirming the deletion of a playlist.
 */
public class DeletePlaylistDialog {

    private final Context context;
    private final PlaylistManager playlistManager;
    private final Playlist playlist;

    public DeletePlaylistDialog(Context context, Playlist playlist) {
        this.context = context;
        this.playlistManager = PlaylistManager.getInstance();
        this.playlist = playlist;
    }

    public void show() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Playlist");

        // Inflate custom layout
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.dialog_delete_playlist, null);
        builder.setView(view);

        TextView messageTextView = (TextView) view.findViewById(R.id.textview_delete_playlist_message);
        messageTextView.setText("Are you sure you want to delete the playlist '" + playlist.getName() + "'?");

        Button deleteButton = (Button) view.findViewById(R.id.button_delete_playlist);
        Button cancelButton = (Button) view.findViewById(R.id.button_cancel_delete_playlist);

        final AlertDialog dialog = builder.create();

        // Set OnClickListener for the delete button
      /*  deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean deleted = playlistManager.deletePlaylist(playlist);
                    if (deleted) {
                        Toast.makeText(context, "Playlist '" + playlist.getName() + "' deleted.", Toast.LENGTH_SHORT).show();
                        // Optionally refresh UI components that display playlists
                    } else {
                        Toast.makeText(context, "Failed to delete playlist '" + playlist.getName() + "'.", Toast.LENGTH_SHORT).show();
                    }
                    dialog.dismiss();
                }
            });*/

        // Set OnClickListener for the cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });

        dialog.show();
    }
}

