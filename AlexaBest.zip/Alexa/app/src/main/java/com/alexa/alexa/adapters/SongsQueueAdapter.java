package com.alexa.alexa.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;

import java.util.ArrayList;

public class SongsQueueAdapter extends ArrayAdapter<SongItem> {

    private ArrayList<SongItem> songsQueue;
    private Context context;

    public SongsQueueAdapter(Context context, ArrayList<SongItem> songsQueue) {
        super(context, 0, songsQueue);
        this.context = context;
        this.songsQueue = songsQueue;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        SongItem songItem = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.songlist_item, parent, false);
        }

        // Lookup view for data population
        TextView songTitle = convertView.findViewById(R.id.songlist_itemTitle);
        TextView songArtist = convertView.findViewById(R.id.songlist_itemArtist);

        // Populate the data into the template view using the songItem object
        if (songItem != null) {
            songTitle.setText(songItem.getTitle());
            songArtist.setText(songItem.getArtist());
        }

        // Return the completed view to render on screen
        return convertView;
    }
}
