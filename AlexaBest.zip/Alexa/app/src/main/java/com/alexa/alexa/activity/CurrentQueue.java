package com.alexa.alexa.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;
import com.alexa.alexa.ActivityAdapters.CurrentSongQueueAdapter;

public class CurrentQueue extends Activity
 {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_queue);

        // Get the song queue passed via intent
        ArrayList<SongItem> songQueue = getIntent().getParcelableArrayListExtra("songQueue");

        // Display the song queue in a ListView or RecyclerView (if applicable)
        ListView queueListView = findViewById(R.id.queue_list_view);  // Assuming you have a ListView with this ID

        CurrentSongQueueAdapter adapter = new CurrentSongQueueAdapter(this, songQueue);  // Custom adapter to display the queue
        queueListView.setAdapter(adapter);
    }
}
