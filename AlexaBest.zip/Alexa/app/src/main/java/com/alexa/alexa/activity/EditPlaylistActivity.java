package com.alexa.alexa.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.alexa.alexa.R;
import com.alexa.alexa.adapters.SongAdapter; // Assume you have a SongAdapter
import com.alexa.alexa.models.Playlist;


import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.models.SongItem;
import android.widget.Toast;

public class EditPlaylistActivity extends AppCompatActivity {

    private ListView songsListView;
    private SongAdapter songAdapter;
    private Playlist currentPlaylist;
    private List<SongItem> allSongs; // List of all available songs
    private List<SongItem> selectedSongs; // Songs in the playlist

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_playlist);

        songsListView = findViewById(R.id.songs_list_view);
        Button saveButton = findViewById(R.id.save_playlist_button);

        // Retrieve playlist ID from intent
        Intent intent = getIntent();
        int playlistId = intent.getIntExtra("playlistId", -1);

        // Fetch the playlist from your data source (e.g., database)
        currentPlaylist = fetchPlaylistById(playlistId);

        if (currentPlaylist == null) {
            // Handle error: Playlist not found
            finish();
            return;
        }

        // Initialize song lists
        allSongs = fetchAllSongs();
        selectedSongs = new ArrayList<>(currentPlaylist.getSongs());

        // Initialize and set adapter
        songAdapter = new SongAdapter(this, allSongs, selectedSongs);
        songsListView.setAdapter(songAdapter);

        // Save button listener
        saveButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    savePlaylist();
                }
            });
    }

    // Fetch playlist by ID (implement according to your data source)
    private Playlist fetchPlaylistById(int playlistId) {
        // Example implementation
        // Replace with actual data fetching logic
        for (Playlist pl : MainActivity.playlists) { // Assuming playlists are stored in MainActivity
            return pl;
        }
        return null;
    }

    // Fetch all available songs (implement according to your data source)
    private List<SongItem> fetchAllSongs() {
        // Example implementation
        // Replace with actual data fetching logic
        return MainActivity.allSongs; // Assuming all songs are stored in MainActivity
    }

    // Save the updated playlist
    private void savePlaylist() {
        // Update the playlist's songs
        currentPlaylist.setSongs(selectedSongs);

        // Update the data source (e.g., database)
        updatePlaylistInDataSource(currentPlaylist);

        // Notify the user
        Toast.makeText(this, "Playlist updated", Toast.LENGTH_SHORT).show();

        // Finish the activity
        finish();
    }

    // Update playlist in data source (implement according to your data source)
    private void updatePlaylistInDataSource(Playlist playlist) {
        // Example implementation
        // Replace with actual data updating logic
        for (int i = 0; i < MainActivity.playlists.size(); i++) {
            if (MainActivity.playlists.get(i).getId() == playlist.getId()) {
                MainActivity.playlists.set(i, playlist);
                break;
            }
        }
    }
}
