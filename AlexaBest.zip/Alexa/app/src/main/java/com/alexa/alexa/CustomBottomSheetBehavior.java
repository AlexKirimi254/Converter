package com.alexa.alexa;



import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class CustomBottomSheetBehavior<V extends View> extends BottomSheetBehavior<V> {

    private float initialTouchY;
    private boolean isDragging;

    public CustomBottomSheetBehavior() {
        super();
    }

    public CustomBottomSheetBehavior(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(@NonNull CoordinatorLayout parent, @NonNull V child, @NonNull MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                initialTouchY = event.getY();
                isDragging = false;
                break;

            case MotionEvent.ACTION_MOVE:
                float deltaY = event.getY() - initialTouchY;
                if (Math.abs(deltaY) > 10) { // Adjust threshold for drag detection
                    isDragging = true;
                }
                break;

            case MotionEvent.ACTION_UP:
                if (isDragging) {
                    // Handle drag end (if needed)
                } else {
                    // Handle click event
                    performClick();
                }
                break;

            default:
                break;
        }
        return super.onTouchEvent(parent, child, event);
    }

 //   @Override
    public boolean performClick() {
       // return super.performClick();
        return false;
    }
}
