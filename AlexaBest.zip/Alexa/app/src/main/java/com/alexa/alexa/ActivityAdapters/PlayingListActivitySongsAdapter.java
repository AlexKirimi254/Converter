package com.alexa.alexa.ActivityAdapters;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.models.SongItem;
import java.util.ArrayList;

public class PlayingListActivitySongsAdapter extends ArrayAdapter<SongItem> {

        private Context context;
        private ArrayList<SongItem> songs;

        public PlayingListActivitySongsAdapter(Context context, ArrayList<SongItem> songs) {
            super(context, R.layout.activity_playing_list, songs);
            this.context = context;
            this.songs = songs;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Inflate the view for each list item if it is not already done
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate(R.layout.songlist_item, parent, false);
            }

            // Get the song item for this position
            SongItem song = songs.get(position);

            // Find and populate the TextViews in the item layout
            TextView titleTextView = convertView.findViewById(R.id.songlist_itemTitle);
            TextView artistTextView = convertView.findViewById(R.id.songlist_itemArtist);

            titleTextView.setText(song.title);
            artistTextView.setText(song.artist);

            return convertView;
        }
    }

