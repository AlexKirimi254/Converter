package com.alexa.alexa.tabs;

import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.SongListAdaptor;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.view.fastscroll.FastScrollListView;
import com.alexa.alexa.view.tabview.Tab;
import java.util.List;

public class PrioritizedSongsTab extends Tab
 {
    private View root;
    private SongListAdaptor adapter;
    private FastScrollListView list1;
    private List<SongItem> prioritizedSongList;

    public PrioritizedSongsTab(MainActivity ctx) {
        root = LayoutInflater.from(ctx).inflate(R.layout.default_listview, null, false);
        list1 = (FastScrollListView) root.findViewById(R.id.list_view_list1);
        adapter = new SongListAdaptor(ctx);
        list1.setAdapter(adapter);
        list1.setOgtl(new FastScrollListView.GT() {
                @Override
                public String getItemText(int pos) {
                    if (pos < 0) {
                        pos = 0;
                    } else if (pos >= adapter.getCount()) {
                        pos = adapter.getCount() - 1;
                    }
                    if (adapter != null && !adapter.isEmpty()) {
                        SongItem i = adapter.getItem(pos);
                        if (i != null) {
                            String t = i.getTitle();
                            if (t != null && t.length() > 1) {
                                return t.substring(0, 1).toUpperCase();
                            }
                        }
                    }
                    return "...";
                }
            });

        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> p1, View v, int pos, long p4) {
                    SongItem si = (SongItem) v.getTag();
                    AudioService aupod = App.get().getAudioService();
                    if (aupod != null) {
                        aupod.playSong(si);
                    }
                }
            });
    }

    public void update(List<SongItem> prioritizedList) {
        this.prioritizedSongList = prioritizedList;
        adapter.update(prioritizedList);
    }

    @Override
    public void onTabShown() {
        super.onTabShown();
    }

    @Override
    public View getView() {
        return root;
    }

    @Override
    public void onApplyTheme(ThemeManager.Theme theme) {
        if (adapter != null) {
            adapter.setTheme(theme);
        }
        list1.setThumbColor(theme.icon);
        list1.setThumbTextColor(theme.text);
        list1.setDivider(new ColorDrawable(theme.dividers));
    }
}
