package com.alexa.alexa.menu;

import android.app.Dialog;
import android.content.Intent;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.activity.TagEditorActivity;


import com.alexa.alexa.models.SongItem;

public class SongOptions implements View.OnClickListener {

    private MainActivity ctx;
    private SongItem si;
    private RelativeLayout container;
    private TextView title, artist;
    private Dialog dlg;

    public SongOptions(MainActivity ctx, SongItem si) {
        this.ctx = ctx;
        this.si = si;
        dlg = new Dialog(ctx);
        Window w = dlg.getWindow();
        if (w != null) {
            w.requestFeature(Window.FEATURE_NO_TITLE);
        }

        dlg.setContentView(R.layout.dlg_songitem_options);

        title = ftv(R.id.popup_auplayer_songoptions_title);
        artist = ftv(R.id.popup_auplayer_songoptions_artist);

        title.setText(si.getTitle());
        artist.setText(si.getArtist());

        LinearLayout ops = (LinearLayout) fv(R.id.popup_auplayer_songoptions_clk);
        int cc = ops.getChildCount();
        for (int i = 0; i < cc; i++) {
            ops.getChildAt(i).setOnClickListener(this);
        }
    }

    private String getFlag(View v) {
        String[] p = getValues(v);
        if (p != null && p.length >= 2) {
            return p[1];
        }
        return null;
    }

    private String[] getValues(View v) {
        if (v.getTag() != null && (v.getTag() instanceof String)) {
            String t = v.getTag().toString();
            return t.split(" ");
        }
        return null;
    }

    private View fv(int resid) {
        return dlg.findViewById(resid);
    }

    private TextView ftv(int resid) {
        return (TextView) fv(resid);
    }

    public void show() {
        dlg.show();
    }

    public void hide() {
        dlg.dismiss();
        title.setText("");
        artist.setText("");
        si = null;
    }

    @Override
    public void onClick(View v) {
        if (v.getTag() != null) {
            String tag = v.getTag().toString();
            if (tag != null) {
                tag = tag.split(" ")[0];
            }
            switch (tag) {
                case "playnext":
                    ctx.addToQueue(si);
                   // ctx.launchCurrentQueueActivity(); // Launch the CurrentQueue activity after adding to the queue
                    break;
                case "playall":
                    ctx.playAll(si); // Uncomment this line if playAll method is implemented
                    break;
                case "shuffle":
                   // ctx.addToQueues(si);
                    break;
                case "addtoplaylist":
                    ctx.showAddToPlaylistDialog(si); // Show the Add to Playlist dialog
                    break;
                case "editfiletags":
                    Intent intent = new Intent(ctx, TagEditorActivity.class);
                    intent.putExtra("title", si.getTitle());
                    intent.putExtra("artist", si.getArtist());
                    intent.putExtra("album", si.getAlbum());
                    intent.putExtra("genre", si.getGenre());
                    intent.putExtra("year", si.getYear());
                    intent.putExtra("path", si.getPath());
                    ctx.startActivity(intent);
                    break;
                case "deletesong":
                    new ConfirmDeleteDialog(ctx, si).show();
                    break;
                default:
                    break;
            }
        }
        hide();
    }

    
}
