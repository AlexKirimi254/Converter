package com.alexa.alexa.tabs;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.activity.AlbumDetailsActivity;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.adapters.AlbumsListAdaptor;
import com.alexa.alexa.models.AlbumItem;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.view.tabview.Tab;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class AlbumsTab extends Tab {
    MainActivity act;
    View root;
    ListView list1;
    AlbumsListAdaptor adapter;
    List<AlbumItem> albumList;  // Store album list

    public AlbumsTab(MainActivity act) {
        this.act = act;
        root = LayoutInflater.from(act).inflate(R.layout.default_listview, null, false);
        list1 = (ListView) root.findViewById(R.id.list_view_list1);
    }

    public void update(List<SongItem> songList) {
        // Extract unique albums from the song list
        HashSet<String> albumSet = new HashSet<>();
        albumList = new ArrayList<>();
        for (SongItem song : songList) {
            albumSet.add(song.getAlbum());
        }

        // Create an AlbumItem for each unique album
        for (String album : albumSet) {
            List<SongItem> songsInAlbum = new ArrayList<>();
            for (SongItem song : songList) {
                if (song.getAlbum().equals(album)) {
                    songsInAlbum.add(song);
                }
            }
            albumList.add(new AlbumItem(album, songsInAlbum));
        }

        // Set the adapter and handle click events
        adapter = new AlbumsListAdaptor(act, albumList);
        list1.setAdapter(adapter);

        // Set item click listener to open album details when clicked
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					AlbumItem selectedAlbum = albumList.get(position);

					// Open AlbumDetailsActivity with the selected album
					Intent intent = new Intent(act, AlbumDetailsActivity.class);
					intent.putExtra("albumName", selectedAlbum.getAlbumName());
                    
                    intent.putExtra("song_count", selectedAlbum.getSongcount());
                    intent.putExtra("album_count", selectedAlbum.getAlbumCount()); 
					intent.putParcelableArrayListExtra("songList", new ArrayList<>(selectedAlbum.getSongList()));
					act.startActivity(intent);
				}
			});
    }

    @Override
    public View getView() {
        return root;
    }

    @Override
    public void onApplyTheme(ThemeManager.Theme theme) {
        // Apply the theme if necessary
    }
}
