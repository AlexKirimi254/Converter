package com.alexa.alexa.activity;

import android.app.Activity;
import android.media.audiofx.Equalizer;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import com.alexa.alexa.R;

public class EqualizerActivity extends BaseActivity {
    private Equalizer equalizer;
    private SeekBar[] seekBars;
    private TextView[] labels;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equalizer);

        // Assuming the equalizer is initialized in AudioService and passed via Intent
        int audioSessionId = getIntent().getIntExtra("AUDIO_SESSION_ID", -1);
        initializeEqualizer(audioSessionId);
    }

    private void initializeEqualizer(int audioSessionId) {
        equalizer = new Equalizer(0, audioSessionId);
        equalizer.setEnabled(true);

        short numBands = equalizer.getNumberOfBands();
        seekBars = new SeekBar[numBands];
        labels = new TextView[numBands];

        final short lowerBandLevel = equalizer.getBandLevelRange()[0];
        short upperBandLevel = equalizer.getBandLevelRange()[1];

        // For each band, create a seek bar and label
        for (short i = 0; i < numBands; i++) {
            final short band = i;
            seekBars[i] = new SeekBar(this);
            labels[i] = new TextView(this);

            labels[i].setText((equalizer.getCenterFreq(band) / 1000) + " Hz");

            seekBars[i].setMax(upperBandLevel - lowerBandLevel);
            seekBars[i].setProgress(equalizer.getBandLevel(band) - lowerBandLevel);

            seekBars[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						equalizer.setBandLevel(band, (short) (progress + lowerBandLevel));
					}

					@Override
					public void onStartTrackingTouch(SeekBar seekBar) { }

					@Override
					public void onStopTrackingTouch(SeekBar seekBar) { }
				});

            // Add the seekbars and labels to the layout
            // You can arrange them as per your design
        }
    }

    @Override
    protected void onDestroy() {
        if (equalizer != null) {
            equalizer.release();
        }
        super.onDestroy();
    }
}
