package com.alexa.alexa.activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.Switch;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.alexa.alexa.R;
import com.alexa.alexa.ui.settings.SettingsTab;
import com.alexa.alexa.view.tabview.TabView;
import java.util.HashMap;
import java.util.Map;
import android.widget.Button;

public class SettingsActivity extends BaseActivity {
  SettingsTab st;
    public static final int REQUEST_CODE = 333749;
    private FrameLayout tabContainer;
    private Switch themeSwitch;
    private RadioGroup radioGroup;
    private int mAccent;
    private boolean sThemeInverted;
    private boolean sSearchBarVisible;
	private TabView tabview;
    // HashMap to store the different settings tabs
    private Map<String, SettingsTab> tabs = new HashMap<>();
    private String currentTab = "";
  private Button btn_interface,btn_headset,btn_library,btn_notifications;
   private String tab_interface = "interface";
    private String tab_library = "library";
   private String tab_headset = "headset";
    private String tab_notifications = "notifications";
  
    @Override
    public void onCreate(Bundle savedInstanceState) {
		//setThemeable(true);
        super.onCreate(savedInstanceState);

        // Retrieve user preferences
        SharedPreferences preferences = getSharedPreferences("settings", MODE_PRIVATE);
        sThemeInverted = preferences.getBoolean("theme_inverted", false);
        mAccent = preferences.getInt("accent_color", 0);  // Default accent color
        sSearchBarVisible = preferences.getBoolean("search_bar_visible", true);

        // Apply theme based on user preferences
        applyTheme();

        setContentView(R.layout.activity_settings);

        // Initialize tabs and UI elements
        setupTabs();
        themeSwitch = findViewById(R.id.themeSwitch);
        radioGroup = findViewById(R.id.radioGroup);
        tabContainer = findViewById(R.id.tab_container);
		btn_interface = findViewById(R.id.btn_interface);
		btn_headset = findViewById(R.id.btn_headset);
        btn_library = findViewById(R.id.btn_library);
		btn_notifications = findViewById(R.id.btn_notifications);
        // Setup listeners for user actions
        setupListeners();

        // Request necessary permissions
        requestPermissions();
		
		showTab(tab_interface);
    }

    // Apply theme based on user settings
    private void applyTheme() {
        if (sThemeInverted) {
            setTheme(R.style.AppTheme);
        } else {
            setTheme(R.style.AppThemePurple);
        }
    }

    // Register all the available tabs
    private void setupTabs() {
		tabview = findViewById(R.id.activity_main_tabview1)	;
	         // Create SettingsTab instances and associate them with tab names
        tabs.put(tab_interface, st);
        tabs.put(tab_library,st);
        tabs.put(tab_headset, st);
        tabs.put(tab_notifications, st);
    }

    // Show the selected tab
    private void showTab(String name) {
        if (!currentTab.equals(name)) {
            SettingsTab tab = tabs.get(name);
            if (tab != null) {
                tabContainer.removeAllViews();  // Clear previous tab view
                tabContainer.addView(tab.getView());  // Add the new tab's view
                tabContainer.setVisibility(View.VISIBLE);
                currentTab = name;
            }
        }
    }

    // Handle switching between light and dark themes
    private void setupListeners() {
        // Inside the setupListeners method in SettingsActivity
		themeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
					if (isChecked) {
						editor.putBoolean("theme_inverted", true);
						setTheme(android.R.style.Theme_Light);
					} else {
						editor.putBoolean("theme_inverted", false);
						setTheme(android.R.style.Theme_Black);
					}
					editor.apply();
					recreate();  // Recreate activity to apply theme change

					// Notify MainActivity to recreate after theme change
					Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				}
			});

        findViewById(R.id.activity_main_btn_themeSwitch).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					int selectedTheme = radioGroup.getCheckedRadioButtonId();
					SharedPreferences.Editor editor = getSharedPreferences("settings", MODE_PRIVATE).edit();
					switch (selectedTheme) {
						case R.id.radioLight:
							editor.putBoolean("theme_inverted", false);
							setTheme(R.style.AppThemeAmber);
							break;
						case R.id.radioDark:
							editor.putBoolean("theme_inverted", true);
							setTheme(R.style.AppThemeBlueInverted);
							break;
					}
					editor.apply();
					recreate();  // Recreate activity to apply theme change
				}
			});

        // Add listeners for switching tabs
        btn_interface.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showTab("interface");
				}
			});

        btn_library.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showTab("library");
				}
			});

        btn_headset.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showTab("headset");
				}
			});

        btn_notifications.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showTab("notifications");
				}
			});
    }

    // Handle requesting necessary permissions
    private void requestPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
											  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_CODE);
        }
    }

    @Override
    public void onBackPressed() {
        // Handle back press when a tab is open
        if (tabContainer.getVisibility() == View.VISIBLE) {
            tabContainer.setVisibility(View.GONE);  // Close the tab container
            currentTab = "";  // Reset the current tab state
        } else {
            super.onBackPressed();
        }
    }
}
