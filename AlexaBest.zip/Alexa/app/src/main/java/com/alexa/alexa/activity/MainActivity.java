package com.alexa.alexa.activity;


import android.Manifest;
import android.animation.Animator;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Parcelable;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewTreeObserver;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.ColorUtils;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.alexa.alexa.APEvents;
import com.alexa.alexa.App;
import com.alexa.alexa.R;
import com.alexa.alexa.SearchPanel;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.adapters.ColorsAdapter;
import com.alexa.alexa.adapters.PlayerAdapter;
import com.alexa.alexa.adapters.SongListAdaptor;
import com.alexa.alexa.library.PlaylistManager;
import com.alexa.alexa.menu.AddToPlaylistDialog;
import com.alexa.alexa.menu.ConfirmDeleteDialog;
import com.alexa.alexa.menu.CreatePlaylistDialog;
import com.alexa.alexa.menu.MainActOptions;
import com.alexa.alexa.models.Playlist;
import com.alexa.alexa.models.Song;
import com.alexa.alexa.models.SongItem;
import com.alexa.alexa.service.AudioService;
import com.alexa.alexa.service.PlaybackInfoListener;
import com.alexa.alexa.tabs.AlbumsTab;
import com.alexa.alexa.tabs.ArtistTab;
import com.alexa.alexa.tabs.PlaylistsTab;
import com.alexa.alexa.tabs.SongsListTab;
import com.alexa.alexa.tabs.SongsQueueTab;
import com.alexa.alexa.utils.BitmapUtils;
import com.alexa.alexa.utils.EqualizerUtils;
import com.alexa.alexa.utils.IndexBarRecyclerView;
import com.alexa.alexa.utils.IndexBarView;
import com.alexa.alexa.utils.Utils;
import com.alexa.alexa.view.TintedImageView;
import com.alexa.alexa.view.tabview.TabView;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.card.MaterialCardView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.alexa.alexa.adapters.ArtistListAdapter;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.view.Util;
import com.alexa.alexa.utils.Notific;
import com.alexa.alexa.library.SongLibrary;
import com.alexa.alexa.models.AlbumItem;
import com.alexa.alexa.adapters.AlbumsListAdaptor;

/**
 * Main activity for the audio application.
 */
public class MainActivity extends BaseActivity implements
AudioService.ConnectionListener,
APEvents.PlaybackStateListener,
APEvents.SongListUpdateListener,
SearchPanel.OnSearchResultItemClickListener,
View.OnClickListener {
    public static List<Playlist> playlists; // Initialize appropriately
    public static List<SongItem> allSongs; // Initialize appropriately

    private AudioService aupod;
    private ImageView currentImage;
    public static final int REQUEST_CODE = 22466;
    private ListView list001;
    private SongListAdaptor sAdaptor;
    private TextView currentsongTitle, currentsongArtist;
    private TintedImageView btnPlayPause;
    private TabView tabview;
    private SongsListTab songsTab;
    private ArtistTab artistTab;
    private AlbumsTab albumsTab;
    private PlaylistsTab playlistTab;
    private SongsQueueTab sqTab;
    private SearchPanel searchPanel;
    private List<SongItem> songslist;
    private Handler handle = new Handler();
    private BottomSheetDialog bottomSheetDialog;
    private PlaylistManager playlistManager;
    private ArrayList<SongItem> songQueue = new ArrayList<>();
    private Context context;
    // UI buttons for playlist operations

	private ImageView playPauseButton;
	private boolean isPlaying = false;
	private Switch themeSwitch;
	private RadioGroup radioGroup;

	
	
	
	
	
	//Artist activitySense
	
	private LinearLayoutManager mArtistsLayoutManager, mAlbumsLayoutManager, mSongsLayoutManager;
    private int mAccent;
    private boolean sThemeInverted;
    private boolean sSearchBarVisible;
    private IndexBarRecyclerView mArtistsRecyclerView;
    private RecyclerView mAlbumsRecyclerView, mSongsRecyclerView;
    private ArtistListAdapter mArtistsAdapter;
    private SongListAdaptor mSongsAdapter;
    private TextView mPlayingAlbum, mPlayingSong, mDuration, mSongPosition, mSelectedDiscographyArtist, mSelectedArtistDiscCount, mSelectedDiscographyDisc, mSelectedDiscographyDiscYear;
    private SeekBar mSeekBarAudio;
    private LinearLayout mControlsContainer;
    private BottomSheetBehavior mBottomSheetBehaviour;
    private View mPlayerInfoView, mArtistDetails;
    private ImageView mPlayPauseButton, mSkipPrevButton;
    private PlayerAdapter mPlayerAdapter;
    private boolean mUserIsSeeking = false;
    private List<ArtistItem> mArtists;
    private String mNavigationArtist;
    private boolean sExpandArtistDiscography = false;
    private boolean sPlayerInfoLongPressed = false;
    private boolean sArtistDiscographyDiscLongPressed = false;
    private boolean sArtistDiscographyExpanded = false;
    
    private PlaybackListener mPlaybackListener;
    private List<Song> mSelectedArtistSongs;
    
    private boolean sBound;
    private Parcelable mSavedArtistRecyclerLayoutState;
    private Parcelable mSavedAlbumsRecyclerLayoutState;
    private Parcelable mSavedSongRecyclerLayoutState;

	private ArtistItem artistdetails;

	private static final int durations = 0;

	private int pos;
    
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
       setThemeable(true);
        App.get().setMainActivity(this);
        super.onCreate(savedInstanceState);
		
		sThemeInverted = ThemeManager.isThemeInverted(this);
        mAccent = ThemeManager.getAccent(this);
        sSearchBarVisible = ThemeManager.isSearchBarVisible(this);

        ThemeManager.setTheme(this, sThemeInverted, mAccent);

        setContentView(R.layout.activity_main);

      //  getViews();

        //initializeSettings();
//
        //setupViewParams();

        //initializeSeekBar();

      //  doBindService();
		
        
        playPauseButton = findViewById(R.id.activity_main_iv_playpause);
		themeSwitch = findViewById(R.id.themeSwitch);
		radioGroup = findViewById(R.id.radioGroup);

		// Set up listeners
		setupListeners();

		// Check saved theme preference
		setupThemeSwitch();// Request permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                                              new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);
        }
        PlaylistManager.initialize(this.getApplicationContext());
        // Assume you have set up tabs like PlaylistsTab, etc.

        // Bind to AudioService
        Intent serviceIntent = new Intent(this, AudioService.class);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);


        init();
    }

    private void init() {
        setupUI();
        setupTabs();
        setupBottomSheet();
        //    setupPlaylistButtons();
        playlistManager = PlaylistManager.getInstance(); // Initialize PlaylistManager
    }

    private void setupUI() {
        currentsongTitle = (TextView) findViewById(R.id.activity_main_tv_title);
        currentsongArtist = (TextView) findViewById(R.id.activity_main_tv_artist);
        currentImage = (ImageView) findViewById(R.id.activity_main_iv_currentimage);
        btnPlayPause = (TintedImageView) findViewById(R.id.activity_main_iv_playpause);
        btnPlayPause.setBackgroundResource(R.drawable.ic_play);

        searchPanel = new SearchPanel(this, this);
    }

    private void setupTabs() {
        tabview = (TabView) findViewById(R.id.activity_main_tabview1);
        songsTab = new SongsListTab(this);
        sqTab = new SongsQueueTab(this);
        artistTab = new ArtistTab(this);
        albumsTab = new AlbumsTab(this);
        playlistTab = new PlaylistsTab(this); // Initialize PlaylistsTab with context
	    tabview.addTab("QUEUE", sqTab);
        tabview.addTab("SONGS", songsTab);
	    tabview.addTab("ARTIST", artistTab);
        tabview.addTab("ALBUMS", albumsTab);
        tabview.addTab("PLAYLIST", playlistTab);
        tabview.showTab(songsTab);
    }

    private void setupBottomSheet() {
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_layout, null);
        bottomSheetDialog = new BottomSheetDialog(this);
        bottomSheetDialog.setContentView(bottomSheetView);

        View rr1 = findViewById(R.id.rr1);
        rr1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    bottomSheetDialog.show();
                }
            });
    }






	private void setupListeners() {
		/*findViewById(R.id.activity_main_btn_playpause).setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View v) {
		 togglePlayPause();
		 }
		 });

		 findViewById(R.id.activity_main_btn_next).setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View v) {
		 // Handle next button click
		 Toast.makeText(MainActivity.this, "Next Song", Toast.LENGTH_SHORT).show();
		 }
		 });

		 findViewById(R.id.activity_main_btn_search).setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View v) {
		 // Handle search button click
		 Toast.makeText(MainActivity.this, "Search Clicked", Toast.LENGTH_SHORT).show();
		 }
		 });

		 findViewById(R.id.activity_main_btn_showsettings).setOnClickListener(new View.OnClickListener() {
		 @Override
		 public void onClick(View v) {
		 // Handle settings button click
		 Toast.makeText(MainActivity.this, "Settings Clicked", Toast.LENGTH_SHORT).show();
		 }
		 });
		 */
		 
		 
		findViewById(R.id.activity_main_btn_themeSwitch).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					// Switch between themes based on RadioButton selection
					int selectedTheme = radioGroup.getCheckedRadioButtonId();
					if (selectedTheme == R.id.radioSystem) {
						Toast.makeText(MainActivity.this, "System Default Theme", Toast.LENGTH_SHORT).show();
					} else if (selectedTheme == R.id.radioLight) {
						Toast.makeText(MainActivity.this, "Light Theme", Toast.LENGTH_SHORT).show();
						setTheme(android.R.style.Theme_DeviceDefault_Light_NoActionBar);
					} else if (selectedTheme == R.id.radioDark) {
						Toast.makeText(MainActivity.this, "Dark Theme", Toast.LENGTH_SHORT).show();
						setTheme(android.R.style.ThemeOverlay_Material_Dark);
					}
				}
			});

		themeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					if (isChecked) {
						Toast.makeText(MainActivity.this, "Dark Theme Enabled", Toast.LENGTH_SHORT).show();
						setTheme(android.R.style.Theme_Light);
					} else {
						Toast.makeText(MainActivity.this, "Light Theme Enabled", Toast.LENGTH_SHORT).show();
						setTheme(android.R.style.Theme_Black);
					}
				}
			});
	}

	private void togglePlayPause() {
		if (isPlaying) {
			// Pause the music
			playPauseButton.setBackgroundResource(R.drawable.ic_play);
			isPlaying = true;
			Toast.makeText(MainActivity.this, "Paused", Toast.LENGTH_SHORT).show();
		} else {
			// Play the music
			playPauseButton.setBackgroundResource(R.drawable.ic_pause);
			isPlaying = true;
			Toast.makeText(MainActivity.this, "Playing", Toast.LENGTH_SHORT).show();
		}
	}

	private void setupThemeSwitch() {
		// Initialize the theme based on user's preference (You may save and retrieve this from SharedPreferences)
		themeSwitch.setChecked(true); // Assuming Light Theme by default
	}

	// Handle other lifecycle methods if needed




	// Service connection to bind with AudioService
	private ServiceConnection serviceConnection = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			AudioService.LocalBinder binder = (AudioService.LocalBinder) service;
			aupod = binder.getService();
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			aupod = null;
		}
	};





    // Method to play a playlist
    public void playPlaylist(Playlist playlist) {
        if (playlist == null || playlist.getSongs().isEmpty()) {
            Toast.makeText(this, "Playlist is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Implement playback logic here
        // For example, start a service or an activity to handle audio playback

        // Example Toast (replace with actual playback code)
        Toast.makeText(this, "Playing playlist: " + playlist.getName(), Toast.LENGTH_SHORT).show();

        // Example: Start PlaybackActivity

        Intent playbackIntent = new Intent(this, PlaylistDetailsActivity.class);
        playbackIntent.putExtra("playlistId", playlist.getId());
        startActivity(playbackIntent);


    }


    // Method to show a confirmation dialog before deleting the playlist




    /**
     * Launches the AddToPlaylistDialog to allow the user to add a song to a playlist.
     *
     * @param si The SongItem to be added to a playlist.
     */
    public void showAddToPlaylistDialog(SongItem si) {
        AddToPlaylistDialog dialog = new AddToPlaylistDialog(this, si);
        dialog.show();
    }

    /**
     * Adds a song to the queue.
     *
     * @param song The SongItem to add to the queue.
     */
    public void addToQueue(SongItem song) {
        if (aupod != null) {
            aupod.playSong(song);
            Toast.makeText(this, song.getTitle() + " added to queue.", Toast.LENGTH_SHORT).show();
        }
        songQueue.add(song);
    }

    public void launchCurrentQueueActivity() {
        Intent intent = new Intent(this, CurrentQueue.class);
        intent.putParcelableArrayListExtra("songQueue", songQueue);
        startActivity(intent);
    }

    public void showEditFileTagsDialog(SongItem si) {
        Intent intent = new Intent(this, TagEditorActivity.class);
        startActivity(intent);
    }


    public void addToQueuee(SongItem si) {
		// sqTab.addSongToQueue(si);

        aupod.addToQueue(si);
		Toast.makeText(this, si.getTitle() + " added to queue.", Toast.LENGTH_SHORT).show();

    }

    public void playAll(SongItem si) {
        if (aupod != null) {
			//  aupod.playAll(si);
            Toast.makeText(this, "Playing all songs from '" + si.getTitle() + "'.", Toast.LENGTH_SHORT).show();
        }
    }

    public void confirmDeleteSong(SongItem si) {
        new ConfirmDeleteDialog(this, si).show();
    }

    /**
     * Shows the dialog to create a new playlist.
     */
    public void showCreatePlaylistDialog() {
        CreatePlaylistDialog dialog = new CreatePlaylistDialog(this);
        dialog.show();
    }

    // Assuming this is triggered from SongOptions
    public void onPlayNextSelected(SongItem songTitle) {
        // Add the song to the queue
        sqTab.addSongToQueue(songTitle);

        // Check if the audio service is currently playing something
        if (aupod != null) {
            if (!aupod.isPlaying()) {
                // If nothing is playing, start playback immediately
                aupod.playSong(songTitle);
            } else {
                // If a song is currently playing, let the queue handle it after the current song finishes
                // No need to call playSong here to avoid interrupting current playback
            }
        }
    }


    // Method to refresh PlaylistsTab
    public void refreshPlaylistsTab() {
        if (playlistTab != null) {
            playlistTab.refreshData();
        } else {
            // Handle the null scenario, possibly re-initialize the tab
            // or log an error
            Log.e("MainActivity", "PlaylistsTab is not initialized");
        }
    }


    /**
     * Refreshes the PlaylistsTab to display the latest playlists.
     */


    // ... [Rest of your MainActivity code remains unchanged]

    @Override
    protected void onResume() {
        super.onResume();
        APEvents.getInstance().addPlaybackEventListener(this);
        APEvents.getInstance().addSongsListUpdateListener(this);
        AudioService.connect(this, this);
        refreshPlaylistsTab(); // Refresh playlists when activity resumes
		if (mPlayerAdapter != null && mPlayerAdapter.isMediaPlayer()) {
            mPlayerAdapter.onResumeActivity();
        }
		
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.activity_main_btn_showsettings:
                new MainActOptions(this).show();
                break;
            case R.id.activity_main_btn_search:
                searchPanel.show(songslist);
                break;
            case R.id.activity_main_btn_shuffle:
                if (aupod != null) {
					aupod.shuffleAll();
                }
                break;
            case R.id.activity_main_btn_prev:
                if (aupod != null) {
                    aupod.playPrevious();
                }
                break;
            case R.id.activity_main_btn_playpause:
                if (aupod != null) {
                    aupod.playPause();

                }
				togglePlayPause();
                break;
            case R.id.activity_main_btn_next:
                if (aupod != null) {
                    aupod.playNext();
                }
                break;
            case R.id.activity_main_btn_settings:
                bottomSheetDialog.show();
                break;
			case R.id.button_equalizer:
				startActivity(EqualizerActivity.class);  
                break;
				
                case R.id.button_create_new_playlist:
                 showAddToPlaylistDialog(aupod.getCurrentSong());
                 break;
        }
    }

    public void showFullPlayer(View v) {
        Intent intent = new Intent(this, PlayerActivity.class);
        startActivity(intent);
    }







    @Override
    public void onAudioServiceConnect(AudioService service){
        aupod = service;
        aupod.getSongsList();
        if(aupod.isPlaying()){
            onPlaybackStart();
        }
    }

    int t=1;
    @Override
    public void onSongsListUpdated(List<SongItem> list){
        songsTab.update(list);
        albumsTab.update(list);
        //
        songslist = list;
        toast("onSongsListUpdated:"+t);
        t++;
        if(aupod!=null){
            SongItem si = aupod.getCurrentSong();
            if(si!=null){
                songsTab.setCurrent(si);
            }
        }
    }    

    public AudioService getAudioService(){
        return aupod;
    }

    @Override
    public void onPlaybackStart(){
		handle.postDelayed(new Runnable(){
				public void run(){
					btnPlayPause.setBackgroundResource(R.drawable.ic_pause);
					btnPlayPause.reset();
				}
			},10);
    }

    @Override
    public void onPlaybackPause()
    {
        handle.postDelayed(new Runnable(){
				public void run(){
					btnPlayPause.setBackgroundResource(R.drawable.ic_play);
					btnPlayPause.reset();
				}
			}, 10);
    }

    @Override
    public void onPlaybackStop()
    {
        handle.postDelayed(new Runnable(){
				public void run(){
					btnPlayPause.setBackgroundResource(R.drawable.ic_play);
					btnPlayPause.reset();
				}
			}, 10);
    }

    @Override
    public void onSongChanged(final SongItem si){
        currentsongTitle.setText(si.title);
        currentsongArtist.setText(si.artist);
        if(si.getThumbnail()!=null){
            currentImage.setBackgroundDrawable(new BitmapDrawable(si.getThumbnail()));
        }else{
            currentImage.setImageBitmap(BitmapUtils.tint(ctx.getResources(), R.drawable.cover_f, ThemeManager.getTheme().background));
        }
        //
        songsTab.setCurrent(si);
    }


    @Override
    public void onSearchResultItemClick(SongItem song) {
        if (aupod != null) {
            aupod.playSong(song);
        }
    }

    void unsubscribe() {
        APEvents.getInstance().removePlaybackEventListener(this);
        APEvents.getInstance().removeSongsListUpdateListener(this);
    }

    
	
	/*@Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.activity_main_drawer, menu);

        final MenuItem search = menu.findItem(R.id.search);
        final SearchView searchView = (SearchView) search.getActionView();

        searchView.setIconifiedByDefault(false);
        ThemeManager.setupSearch(searchView, mArtistsAdapter, mArtists, list001);

        return true;
    }

    */

    @Override
    public void onPause() {
        super.onPause();
        if (mArtistsLayoutManager != null && mAlbumsLayoutManager != null && mSongsLayoutManager != null) {
            mSavedArtistRecyclerLayoutState = mArtistsLayoutManager.onSaveInstanceState();
            mSavedAlbumsRecyclerLayoutState = mAlbumsLayoutManager.onSaveInstanceState();
            mSavedSongRecyclerLayoutState = mSongsLayoutManager.onSaveInstanceState();
        }
        if (mPlayerAdapter != null && mPlayerAdapter.isMediaPlayer()) {
            mPlayerAdapter.onPauseActivity();
        }
    }

    

    @Override
    public void onBackPressed() {
        //if the bottom sheet is expanded collapse it
        if (mBottomSheetBehaviour.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            mBottomSheetBehaviour.setState(BottomSheetBehavior.STATE_COLLAPSED);
            //then collapse the artist discography view
        } else if (sArtistDiscographyExpanded) {
            revealView(mArtistDetails, mArtistsRecyclerView, false);
        } else {
            super.onBackPressed();
        }
    }

    
/*
    private void getViews() {

		mControlsContainer = findViewById(R.id.controls_container);
		final View contextView = findViewById(R.id.context_view);
		contextView.setBackgroundColor(ColorUtils.setAlphaComponent(Utils.getColorFromResource(this, mAccent, R.color.blue), sThemeInverted ? 10 : 40));

		final MaterialCardView bottomSheetLayout = findViewById(R.id.design_bottom_sheet);
		mBottomSheetBehaviour = BottomSheetBehavior.from(bottomSheetLayout);

		final Toolbar searchToolbar = findViewById(R.id.search_toolbar);
		searchToolbar.setVisibility(sSearchBarVisible ? View.VISIBLE : View.GONE);
		if (sSearchBarVisible) {
			getActionBar(searchToolbar);
		}

		mArtistDetails = findViewById(R.id.artist_details);
		mPlayerInfoView = findViewById(R.id.player_info);
		mPlayingSong = findViewById(R.id.playing_song);
		mPlayingAlbum = findViewById(R.id.playing_album);

		setupPlayerInfoTouchBehaviour();

		mPlayPauseButton = findViewById(R.id.play_pause);

		mSkipPrevButton = findViewById(R.id.skip_prev);
		mSkipPrevButton.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					setRepeat();
					return false;
				}
			});
		mSeekBarAudio = findViewById(R.id.seekTo);

		mDuration = findViewById(R.id.duration);
		mSongPosition = findViewById(R.id.song_position);
		mSelectedDiscographyArtist = findViewById(R.id.selected_discography_artist);
		mSelectedArtistDiscCount = findViewById(R.id.selected_artist_album_count);
		mSelectedDiscographyDisc = findViewById(R.id.selected_disc);
		setupArtistDiscographyDiscBehaviour();
		mSelectedDiscographyDiscYear = findViewById(R.id.selected_disc_year);

		mArtistsRecyclerView = findViewById(R.id.artists_rv);
		mAlbumsRecyclerView = findViewById(R.id.albums_rv);
		mSongsRecyclerView = findViewById(R.id.songs_rv);
	}
*/
//https://stackoverflow.com/questions/6183874/android-detect-end-of-long-press
	private void setupPlayerInfoTouchBehaviour() {
		mPlayerInfoView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					if (!sPlayerInfoLongPressed) {
						mPlayingSong.setSelected(true);
						mPlayingAlbum.setSelected(true);
						sPlayerInfoLongPressed = true;
					}
					return true;
				}
			});
		mPlayerInfoView.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (sPlayerInfoLongPressed && (event.getAction() == MotionEvent.ACTION_UP ||
						event.getAction() == MotionEvent.ACTION_OUTSIDE ||
						event.getAction() == MotionEvent.ACTION_MOVE)) {
						mPlayingSong.setSelected(false);
						mPlayingAlbum.setSelected(false);
						sPlayerInfoLongPressed = false;
					}
					return false;
				}
			});
	}

	private void setupArtistDiscographyDiscBehaviour() {
		mSelectedDiscographyDisc.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					if (!sArtistDiscographyDiscLongPressed) {
						mSelectedDiscographyDisc.setSelected(true);
						sArtistDiscographyDiscLongPressed = true;
					}
					return true;
				}
			});
		mSelectedDiscographyDisc.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					if (sArtistDiscographyDiscLongPressed && (event.getAction() == MotionEvent.ACTION_UP ||
						event.getAction() == MotionEvent.ACTION_OUTSIDE ||
						event.getAction() == MotionEvent.ACTION_MOVE)) {
						mSelectedDiscographyDisc.setSelected(false);
						sArtistDiscographyDiscLongPressed = false;
					}
					return false;
				}
			});
	}
    private void setupViewParams() {
        final ViewTreeObserver observer = mControlsContainer.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {
					final int controlsContainerHeight = mControlsContainer.getHeight();

					//add bottom margin to those recycler view to avoid they are covered by bottom sheet
					final FrameLayout.LayoutParams artistsLayoutParams = (FrameLayout.LayoutParams) mArtistsRecyclerView.getLayoutParams();
					artistsLayoutParams.bottomMargin = controlsContainerHeight;

					final LinearLayout.LayoutParams songsLayoutParams = (LinearLayout.LayoutParams) mSongsRecyclerView.getLayoutParams();
					songsLayoutParams.bottomMargin = controlsContainerHeight;

					mBottomSheetBehaviour.setPeekHeight(controlsContainerHeight);
					mControlsContainer.getViewTreeObserver().removeOnGlobalLayoutListener(this);
				}
			});
    }

    private void initializeSettings() {
        if (!EqualizerUtils.hasEqualizer(this)) {
            final ImageView eqButton = findViewById(R.id.eq);
            eqButton.setColorFilter(Color.GRAY, PorterDuff.Mode.SRC_IN);
        }
        if (!sSearchBarVisible) {
            final ImageView searchPrefButton = findViewById(R.id.search);
            searchPrefButton.setColorFilter(Color.GRAY, PorterDuff.Mode.SRC_IN);
        }
        initializeColorsSettings();
    }

    public void shuffleSongs(@NonNull final View v) {
        final List<Song> songs = sArtistDiscographyExpanded ? mSelectedArtistSongs : SongLibrary.getInstance().getSongsByArtist(artistdetails);
        Collections.shuffle(songs);
    //    onSongsListUpdated(songs.get(0));
    }

    private void setArtistsRecyclerView(@NonNull final List<ArtistItem> data) {
        mArtistsLayoutManager = new LinearLayoutManager(this);
        mArtistsRecyclerView.setLayoutManager(mArtistsLayoutManager);
     //   mArtistsAdapter = new ArtistListAdapter(this, data);
      //  mArtistsRecyclerView.setAdapter(mArtistsAdapter);
        // Set the FastScroller only if the RecyclerView is scrollable;
        setScrollerIfRecyclerViewScrollable();
    }

    private void setScrollerIfRecyclerViewScrollable() {

        // ViewTreeObserver allows us to measure the layout params
        final ViewTreeObserver observer = mArtistsRecyclerView.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
				@Override
				public void onGlobalLayout() {

					final int h = mArtistsRecyclerView.getHeight();
					mArtistsRecyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
					if (mArtistsRecyclerView.computeVerticalScrollRange() > h) {
						final IndexBarView indexBarView = new IndexBarView(MainActivity.this, mArtistsRecyclerView, mArtistsAdapter, mArtistsLayoutManager, sThemeInverted, ThemeManager.getColorFromResource(MainActivity.this, mAccent, R.color.blue));
						mArtistsRecyclerView.setFastScroller(indexBarView);
					}
				}
			});
    }

    private void initializeSeekBar() {
        mSeekBarAudio.setOnSeekBarChangeListener(
			new SeekBar.OnSeekBarChangeListener() {
				final int currentPositionColor = mSongPosition.getCurrentTextColor();
				int userSelectedPosition = 0;

				@Override
				public void onStartTrackingTouch(@NonNull final SeekBar seekBar) {
					mUserIsSeeking = true;
				}

				@Override
				public void onProgressChanged(@NonNull final SeekBar seekBar, final int progress, final boolean fromUser) {
					if (fromUser) {
						userSelectedPosition = progress;
						mSongPosition.setTextColor(ThemeManager.getColorFromResource(MainActivity.this, mAccent, R.color.blue));
					}
					mSongPosition.setText(Song.formatDuration(progress));
				}

				@Override
				public void onStopTrackingTouch(@NonNull final SeekBar seekBar) {
					if (mUserIsSeeking) {
						mSongPosition.setTextColor(currentPositionColor);
					}
					mUserIsSeeking = false;
					mPlayerAdapter.seekTo(userSelectedPosition);
				}
			});
    }

    private void setRepeat() {
        if (checkIsPlayer()) {
            mPlayerAdapter.reset();
            updateResetStatus(false);
        }
    }

    public void skipPrev(@NonNull final View v) {
        if (checkIsPlayer()) {
            mPlayerAdapter.instantReset();
            if (mPlayerAdapter.isReset()) {
                mPlayerAdapter.reset();
                updateResetStatus(false);
            }
        }
    }

    public void resumeOrPause(@NonNull final View v) {
        if (checkIsPlayer()) {
            aupod.playPause();
        }
    }

    public void skipNext(@NonNull final View v) {
        if (checkIsPlayer()) {
            mPlayerAdapter.skip(true);
        }
    }

    public void openEqualizer(@NonNull final View v) {
        if (EqualizerUtils.hasEqualizer(this)) {
            if (checkIsPlayer()) {
                startActivity(EqualizerUtils.class);
            }
        } else {
            Toast.makeText(this, getString(R.string.no_eq), Toast.LENGTH_SHORT).show();
        }
    }

    public void openGitPage(@NonNull final View v) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.github_url))));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, getString(R.string.no_browser), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public void handleSearchBarVisibility(@NonNull final View v) {
        ThemeManager.hideSearchToolbar(this);
    }

    public void switchTheme(@NonNull final View v) {
        //avoid service killing when the player is in paused state
        if (mPlayerAdapter != null && mPlayerAdapter.getState() == PlaybackInfoListener.State.PAUSED) {
        //    aupod.startForeground(NOTIFICATION_SERVICE);
            //mMusicService.setRestoredFromPause(true);
        }
        ThemeManager.invertTheme(this);
    }

    private boolean checkIsPlayer() {

        boolean isPlayer = aupod.isPlaying();
        if (!isPlayer) {
            EqualizerUtils.notifyNoSessionId(this);
        }
        return isPlayer;
    }

    private void initializeColorsSettings() {
        final RecyclerView colorsRecyclerView = findViewById(R.id.colors_rv);
        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        colorsRecyclerView.setLayoutManager(linearLayoutManager);
        colorsRecyclerView.setAdapter(new ColorsAdapter(this, mAccent));
    }

    

    private void updateResetStatus(final boolean onPlaybackCompletion) {
		final int themeColor = sThemeInverted ? R.color.white : R.color.black;
		final int color = onPlaybackCompletion ? themeColor : mPlayerAdapter.isReset() ? mAccent : themeColor;

		mSkipPrevButton.post(new Runnable() {
				@Override
				public void run() {
					mSkipPrevButton.setColorFilter(
						ThemeManager.getColorFromResource(
							MainActivity.this, 
							color, 
							onPlaybackCompletion ? themeColor : mPlayerAdapter.isReset() ? R.color.blue : themeColor
						), 
						PorterDuff.Mode.SRC_IN
					);
				}
			});
	}

	private void updatePlayingStatus() {
		final int drawable = mPlayerAdapter.getState() != PlaybackInfoListener.State.PAUSED ? R.drawable.ic_pause : R.drawable.ic_play;

		mPlayPauseButton.post(new Runnable() {
				@Override
				public void run() {
					mPlayPauseButton.setImageResource(drawable);
				}
			});
	}

	private void updatePlayingInfo(final boolean restore, final boolean startPlay) {

		if (startPlay) {
			mPlayerAdapter.getMediaPlayer().start();
			new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						onPlaybackStart();
						//AudioService.startForeground(this,serviceConnection);
					}
				}, 250);
		}

		final SongItem selectedSong = mPlayerAdapter.getCurrentSong();
		final long duration = selectedSong.getDuration();
		mSeekBarAudio.setMax(durations);
		ThemeManager.updateTextView(mDuration, Song.formatDuration(durations));

		final Spanned spanned = ThemeManager.buildSpanned(getString(R.string.playing_song, selectedSong.getArtist(), selectedSong.getTitle()));

		mPlayingSong.post(new Runnable() {
				@Override
				public void run() {
					mPlayingSong.setText(spanned);
				}
			});

		ThemeManager.updateTextView(mPlayingAlbum, selectedSong.getAlbum());

		if (restore) {
			mSeekBarAudio.setProgress(mPlayerAdapter.getPlayerPosition());
			updatePlayingStatus();
			updateResetStatus(false);

			new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						//stop foreground if coming from pause state
						if (aupod.isPlaying()) {
							aupod.stopForeground(false);
							}
					}
				}, 250);
		}
	}
    private void restorePlayerStatus() {
        mSeekBarAudio.setEnabled(mPlayerAdapter.isMediaPlayer());
        //if we are playing and the activity was restarted
        //update the controls panel
        if (mPlayerAdapter != null && mPlayerAdapter.isMediaPlayer()) {
            mPlayerAdapter.onResumeActivity();
           // updatePlayingInfo(true, false);
        }
    }

    private void doBindService() {
        // Establish a connection with the service.  We use an explicit
        // class name because we want a specific service implementation that
        // we know will be running in our own process (and thus won't be
        // supporting component replacement by other applications).
        bindService(new Intent(this,
							   AudioService.class), serviceConnection, Context.BIND_AUTO_CREATE);
        sBound = true;

        final Intent startNotStickyIntent = new Intent(this, AudioService.class);
        startService(startNotStickyIntent);
    }

    private void doUnbindService() {
        if (sBound) {
            // Detach our existing connection.
            unbindService(serviceConnection);
            sBound = false;
        }
    }


    private void setArtistDetails(@NonNull final List<AlbumItem> albums, final boolean isNewArtist, final boolean showPlayedArtist) {
        List<AlbumItem> artistAlbums = albums;
        if (showPlayedArtist) {
            final ArtistItem artist = mArtistsAdapter.getItem(pos);
            artistAlbums = artist.getAlbumList();
        }

        ThemeManager.indexArtistAlbums(artistAlbums);

        if (isNewArtist) {
            mAlbumsRecyclerView.scrollToPosition(0);
        }
        mAlbumsLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        mAlbumsRecyclerView.setLayoutManager(mAlbumsLayoutManager);
     //   final AlbumsListAdaptor albumsAdapter = new AlbumsListAdaptor(this, mPlayerAdapter, artistAlbums, showPlayedArtist, ThemeManager.getColorFromResource(this, mAccent, R.color.blue));
   //     mAlbumsRecyclerView.setAdapter(albumsAdapter);

       // mSelectedArtistSongs = SongLibrary.getInstance().getSongsByArtist(artistdetails);
        ThemeManager.updateTextView(mSelectedDiscographyArtist, mNavigationArtist);
        ThemeManager.updateTextView(mSelectedArtistDiscCount, getString(R.string.app_name, artistAlbums.size()));

        if (sExpandArtistDiscography) {
            revealView(mArtistDetails, mArtistsRecyclerView, true);
            sExpandArtistDiscography = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPlaybackListener = null;
        doUnbindService();
    }

    

    

    

    
    public void expandArtistDetailss(@NonNull final View v) {

        if (mPlayerAdapter.getCurrentSong() != null && !mPlayerAdapter.getCurrentSong().getArtist().equals(mNavigationArtist)) {
            // if we come from different artist show the played artist page
        //    onSongChanged(mPlayerAdapter.getCurrentSong().getArtist(), true);
            if (mPlayerAdapter.getCurrentSong() != null) {
                //scrollToPlayedAlbumPosition(false);
            }
        } else if (sArtistDiscographyExpanded) {
            if (mPlayerAdapter.getCurrentSong() != null && mPlayerAdapter.getCurrentSong().getArtist().equals(mNavigationArtist) && !mPlayerAdapter.getNavigationAlbum().equals(mPlayerAdapter.getCurrentSong().getAlbum())) {
                // if the played artist details are already expanded (but not on played album)
                // and we are playing one of his albums, the show the played album
               // mPlayerAdapter.setNavigationAlbum(first);
            } else {
                // if the the played artist details are already expanded
                // but the navigation album equals the played album:
                
            }
        } else {
            if (mPlayerAdapter.getCurrentSong() != null && mPlayerAdapter.getCurrentSong().getArtist().equals(mNavigationArtist)) {
              //  scrollToPlayedAlbumPosition(false);
            }
            revealView(mArtistDetails, mArtistsRecyclerView, true);
        }
    }

    public void closeArtistDetailss(@NonNull final View v) {
        if (sArtistDiscographyExpanded) {
            revealView(mArtistDetails, mArtistsRecyclerView, false);
        }
    }

    private void revealView(@NonNull final View viewToReveal, @NonNull final View viewToHide, final boolean show) {

        final int ANIMATION_DURATION = 500;
        final int viewToRevealHeight = viewToReveal.getHeight();
        final int viewToRevealWidth = viewToReveal.getWidth();
        final int viewToRevealHalfWidth = viewToRevealWidth / 2;
        final int radius = (int) Math.hypot(viewToRevealWidth, viewToRevealHeight);
        final int fromY = viewToHide.getTop() / 2;

        if (show) {
            final Animator anim = ViewAnimationUtils.createCircularReveal(viewToReveal, viewToRevealHalfWidth, fromY, 0, radius);
            anim.setDuration(ANIMATION_DURATION);
            anim.addListener(new Animator.AnimatorListener() {
					@Override
					public void onAnimationStart(Animator animator) {
						viewToReveal.setVisibility(View.VISIBLE);
						viewToHide.setVisibility(View.INVISIBLE);
						viewToReveal.setClickable(false);
						if (getActionBar() != null && sSearchBarVisible && getActionBar().isShowing()) {
							getActionBar().hide();
						}
					}

					@Override
					public void onAnimationEnd(@NonNull final Animator animator) {
						sArtistDiscographyExpanded = true;
					}

					@Override
					public void onAnimationCancel(@NonNull final Animator animator) {
					}

					@Override
					public void onAnimationRepeat(@NonNull final Animator animator) {
					}
				});
            anim.start();

        } else {

            final Animator anim = ViewAnimationUtils.createCircularReveal(viewToReveal, viewToRevealHalfWidth, fromY, radius, 0);
            anim.setDuration(ANIMATION_DURATION);
            anim.addListener(new Animator.AnimatorListener() {
					@Override
					public void onAnimationStart(@NonNull final Animator animator) {
						sArtistDiscographyExpanded = false;
					}

					@Override
					public void onAnimationEnd(@NonNull final Animator animator) {
						viewToReveal.setVisibility(View.INVISIBLE);
						viewToHide.setVisibility(View.VISIBLE);
						viewToReveal.setClickable(true);
						sArtistDiscographyExpanded = false;
						if (getActionBar() != null && sSearchBarVisible && !getActionBar().isShowing()) {
							getActionBar().show();
						}
					}

					@Override
					public void onAnimationCancel(@NonNull final Animator animator) {
					}

					@Override
					public void onAnimationRepeat(@NonNull final Animator animator) {
					}
				});
            anim.start();
        }
    }

    class PlaybackListener extends PlaybackInfoListener {

        @Override
        public void onPositionChanged(int position) {
            if (!mUserIsSeeking) {
                mSeekBarAudio.setProgress(position);
            }
        }

        
	
}}


