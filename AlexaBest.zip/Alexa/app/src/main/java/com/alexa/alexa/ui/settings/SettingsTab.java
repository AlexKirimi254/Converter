package com.alexa.alexa.ui.settings;
import android.view.LayoutInflater;
import android.view.View;
import com.alexa.alexa.activity.SettingsActivity;

// diy fragments
public abstract class SettingsTab
{
    private SettingsActivity act;
    
    public SettingsTab(SettingsActivity act){
        this.act = act;
    }
    
    public SettingsActivity getActivity(){
        return act;
    }
    
    public LayoutInflater getLayoutInflater(){
        return act.getLayoutInflater();
    } 
    
    public abstract View getView();
}
