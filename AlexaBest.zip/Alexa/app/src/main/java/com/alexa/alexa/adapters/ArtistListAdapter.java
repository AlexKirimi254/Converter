package com.alexa.alexa.adapters;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.alexa.alexa.R;
import com.alexa.alexa.ThemeManager;
import com.alexa.alexa.models.ArtistItem;
import com.alexa.alexa.utils.BitmapUtils; // Make sure you have this utility class

import java.util.ArrayList;
import java.util.List;
import com.alexa.alexa.models.SongItem;


public class ArtistListAdapter extends BaseAdapter {
    List<SongItem> songs;
    private LayoutInflater inflater;
    private ThemeManager.Theme theme;
    private List<ArtistItem> artistList = new ArrayList<>();
    private OnItemClickListener itemClickListener;
   
    // Interface for item click callbacks
    public interface OnItemClickListener {
        void onItemClick(ArtistItem artist);
    }

    public ArtistListAdapter(LayoutInflater inflater) {
        this.inflater = inflater;
    }

    // Update the adapter's data
    public void update(List<ArtistItem> list) {
        artistList = list;
        notifyDataSetChanged();
    }

    // Set the theme for the adapter
    public void setTheme(ThemeManager.Theme theme) {
        this.theme = theme;
    }

    // Set the item click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    @Override
    public int getCount() {
        return artistList.size();
    }

    @Override
    public ArtistItem getItem(int position) {
        return artistList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    // Create and bind the view for each artist item
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ArtistItem artist = getItem(position);

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.adapteritem_artist, parent, false);
        }

        TextView nameTextView = convertView.findViewById(R.id.artistlist_itemTitle);
        TextView countTextView = convertView.findViewById(R.id.artistlist_songcount);
        ImageView thumbnailImageView = convertView.findViewById(R.id.artistlist_item_albumart); // Assuming you have an ImageView for the thumbnail

        nameTextView.setText(artist.getName());
        countTextView.setText(artist.getSongcount() + (artist.getSongcount() > 1 ? " songs" : " song"));

        // Load the artist's thumbnail if available
        Bitmap thumbnail = artist.getThumbnail(); // Assuming this method exists
        if (artist.getName() != null) {
            thumbnailImageView.setImageDrawable(new BitmapDrawable(parent.getResources(), artist.getThumbnail()));
        } else {
            ArrayList<SongItem> songList = new ArrayList<>(songs);
            
                      thumbnailImageView.setImageResource(R.drawable.cover_f); // Placeholder image
        }

        // Apply theme colors
        if (theme != null) {
            nameTextView.setTextColor(theme.text);
            countTextView.setTextColor(theme.text);
            // convertView.setBackgroundColor(theme.background);
        }

        // Set the click listener for the item
        convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ArtistItem clickedArtist = getItem(position);
                    if (itemClickListener != null) {
                        itemClickListener.onItemClick(clickedArtist);
                    }
                }
            });

        return convertView;
    }
}
