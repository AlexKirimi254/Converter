package com.alexa.alexa.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import com.alexa.alexa.R;
import com.alexa.alexa.activity.EditPlaylistActivity;
import com.alexa.alexa.activity.MainActivity;
import com.alexa.alexa.models.Playlist;
import java.util.List;
import com.alexa.alexa.App;
public class PlaylistAdapter extends android.widget.BaseAdapter {

    private Context context;
    private List<Playlist> playlists;
    private MainActivity mainActivity;

    public PlaylistAdapter(MainActivity mainActivity, List<Playlist> playlists) {
        this.context = mainActivity;
        this.playlists = playlists;
        this.mainActivity = mainActivity;
    }

    @Override
    public int getCount() {
        return playlists.size();
    }

    @Override
    public Object getItem(int position) {
        return playlists.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.adapteritem_playlist, parent, false);
        }

        Playlist playlist = playlists.get(position);
        TextView playlistName = (TextView) convertView.findViewById(R.id.playlist_name);
        playlistName.setText(playlist.getName());
        ImageView art = (ImageView) convertView.findViewById(R.id.playlist_item_albumart);
        art.setBackgroundResource(R.drawable.cover_f);

        convertView.findViewById(R.id.playlist_item_more).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    showPopupMenu(v, position);
                }
            });

        return convertView;
    }

    // Method to show popup menu with options for each playlist
    private void showPopupMenu(View view, final int position) {
        PopupMenu popupMenu = new PopupMenu(context, view);
        popupMenu.inflate(R.menu.playlist_options_menu);

        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    Playlist selectedPlaylist = playlists.get(position);
                    switch (menuItem.getItemId()) {
                        case R.id.playlist_option_play:
                            // Play playlist
                            App.get() .getAudioService().playSongsFromPlaylist(selectedPlaylist.getSongs(), 0);
                            return true;
                        case R.id.playlist_option_edit:
                            // Edit playlist
                            mainActivity.startActivity(new Intent(mainActivity, EditPlaylistActivity.class));
                            return true;
                        case R.id.playlist_option_delete:
                            playlists.remove(position);
                            notifyDataSetChanged();
                            return true;
                        default:
                            return false;
                    }
                }
            });

        popupMenu.show();
    }

    public void updateList(List<Playlist> newPlaylists) {
        playlists.clear();
        playlists.addAll(newPlaylists);
        notifyDataSetChanged();
    }
}
